<?php
header("Access-Control-Allow-Origin:*");
require('../connexion_bdd.php');


function  addRooms($room_id, $room_num, $HXXType, $ResidentOrGuest, $Etat, $Lign_date , $PassedNights,$RemainingNights, $StayStatus, $RoomStatusAfterH12 ,$Floor_Label,$Floor_Id,$LinkSP, $is_litBebe, $is_porteOuverte, $is_porteFermee, $is_canapeOuvert, $is_canapeFerme, $is_litItalienne, $is_cadeauChocolat, $is_cadeauChampagne, $is_cadeauFleur){

	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);	
	$date =(new \DateTime())->format('Y-m-d H:i:s');
	

		   $result = $bdd->query("INSERT INTO datacsv (room_id, room_num,HXXType,ResidentOrGuest,Etat,Lign_date,PassedNights,RemainingNights,StayStatus,RoomStatusAfterH12,Floor_Label,Floor_Id,LinkSP,Date_created, is_litBebe, is_porteOuverte, is_porteFermee, is_canapeOuvert, is_canapeFerme, is_litItalienne, is_cadeauChocolat, is_cadeauChampagne, is_cadeauFleur)
	 VALUES(
	 '".$room_id."',
	 '".$room_num."',
	 '".$HXXType."',
	 '".$ResidentOrGuest."',
	 '".$Etat."',
	 '".$Lign_date."',
	 '".$PassedNights."',
	 '".$RemainingNights."',
	 '".$StayStatus."',
	 '".$RoomStatusAfterH12."',
	 '".$Floor_Label."',
	 '".$Floor_Id."',
	 '".$LinkSP."',
	 '".$date."',
	 '".$is_litBebe."',
	 '".$is_porteOuverte."'
	 '".$is_porteFermee."'
	 '".$is_canapeOuvert."'
	 '".$is_canapeFerme."'
	 '".$is_litItalienne."'
	 '".$is_cadeauChocolat."'
	 '".$is_cadeauChampagne."'
	 '".$is_cadeauFleur."')") or die(mysqli_error($bdd));

	if ( $bdd->affected_rows > 0 ) {	
	 echo "Insertion dans la tablde de datacsv avec succes !!";
		return true;
	}else{
		echo "Erreur d'insertion dans la tablde de datacsv  !!";
		return false;
	}
	
	deconnection_bdd($bdd);
}


function getAllRooms(){
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM datacsv ORDER BY id ASC") or die(mysqli_error($bdd));

	// check for empty result
	if (mysqli_num_rows($result) > 0) {
		// looping through all results
		$rooms = array();
		 
		while( $row = mysqli_fetch_array($result) ) {
			//$employe = getEmploye_id($row["EMP_ID"]);
			$room["id"] = $row["id"];
			$room["room_id"] = $row["room_id"];
			$room["room_num"] = $row["room_num"];
			$room["HXXType"] = $row["HXXType"];
			$room["ResidentOrGuest"] = $row["ResidentOrGuest"];
			$room["Etat"] = $row["Etat"];			
			$room["Lign_date"] = $row["Lign_date"];
			$room["PassedNights"] = $row["PassedNights"];
			$room["RemainingNights"] = $row["RemainingNights"];
			$room["StayStatus"] = $row["StayStatus"];
			$room["RoomStatusAfterH12"] = $row["RoomStatusAfterH12"];			
			$room["Floor_Label"] = $row["Floor_Label"];
			$room["Floor_Id"] = $row["Floor_Id"];
			$room["LinkSP"] = $row["LinkSP"];
			$room["Date_created"] = $row["Date_created"];
			$room["is_litBebe"] = $row["is_litBebe"];
			$room["is_porteOuverte"] = $row["is_porteOuverte"];
			$room["is_porteFermee"] = $row["is_porteFermee"];
			$room["is_canapeOuvert"] = $row["is_canapeOuvert"];
			$room["is_canapeFerme"] = $row["is_canapeFerme"];
			$room["is_litItalienne"] = $row["is_litItalienne"];
			$room["is_cadeauChocolat"] = $row["is_cadeauChocolat"];
			$room["is_cadeauChampagne"] = $row["is_cadeauChampagne"];
			$room["is_cadeauFleur"] = $row["is_cadeauFleur"];
			array_push($rooms, $room); 
		}
		echo json_encode($rooms);
	} else {
		$error["succes"] = false;
		$error["message"] = "Il y a pas de chambres disponible dans cette hotel";
		// echo no users JSON
		echo json_encode($error);
	}
	deconnection_bdd($bdd);
}

function  getRooms_IdFloor($id_floor){

	
		$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM datacsv 	WHERE Floor_Label=".$id_floor." ORDER BY id ASC") or die(mysqli_error($bdd));

	// check for empty result
	if (mysqli_num_rows($result) > 0) {
		// looping through all results
		$rooms = array();
		 
		while( $row = mysqli_fetch_array($result) ) {
			//$employe = getEmploye_id($row["EMP_ID"]);
			$room["id"] = $row["id"];
			$room["room_id"] = $row["room_id"];
			$room["room_num"] = $row["room_num"];
			$room["HXXType"] = $row["HXXType"];
			$room["ResidentOrGuest"] = $row["ResidentOrGuest"];
			$room["Etat"] = $row["Etat"];			
			$room["Lign_date"] = $row["Lign_date"];
			$room["PassedNights"] = $row["PassedNights"];
			$room["RemainingNights"] = $row["RemainingNights"];
			$room["StayStatus"] = $row["StayStatus"];
			$room["RoomStatusAfterH12"] = $row["RoomStatusAfterH12"];			
			$room["Floor_Label"] = $row["Floor_Label"];
			$room["Floor_Id"] = $row["Floor_Id"];
			$room["LinkSP"] = $row["LinkSP"];
			$room["Date_created"] = $row["Date_created"];
			$room["is_litBebe"] = $row["is_litBebe"];
			$room["is_porteOuverte"] = $row["is_porteOuverte"];
			$room["is_porteFermee"] = $row["is_porteFermee"];
			$room["is_canapeOuvert"] = $row["is_canapeOuvert"];
			$room["is_canapeFerme"] = $row["is_canapeFerme"];
			$room["is_litItalienne"] = $row["is_litItalienne"];
			$room["is_cadeauChocolat"] = $row["is_cadeauChocolat"];
			$room["is_cadeauChampagne"] = $row["is_cadeauChampagne"];
			$room["is_cadeauFleur"] = $row["is_cadeauFleur"];
			array_push($rooms, $room); 
		}
		echo json_encode($rooms);
	} else {
		$error["succes"] = false;
		$error["message"] = "Aucune chambre dans cette etage";
		// echo no users JSON
		echo json_encode($error);
	}
	deconnection_bdd($bdd);
	
}

function getRoomsOccupiedClean(){
		$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM datacsv WHERE Etat='OCC-Prp' ORDER BY id ASC") or die(mysqli_error($bdd));

	// check for empty result
	if (mysqli_num_rows($result) > 0) {
		// looping through all results
		$rooms = array();
		 
		while( $row = mysqli_fetch_array($result) ) {
			//$employe = getEmploye_id($row["EMP_ID"]);
			$room["id"] = $row["id"];
			$room["room_id"] = $row["room_id"];
			$room["room_num"] = $row["room_num"];
			$room["HXXType"] = $row["HXXType"];
			$room["ResidentOrGuest"] = $row["ResidentOrGuest"];
			$room["Etat"] = $row["Etat"];			
			$room["Lign_date"] = $row["Lign_date"];
			$room["PassedNights"] = $row["PassedNights"];
			$room["RemainingNights"] = $row["RemainingNights"];
			$room["StayStatus"] = $row["StayStatus"];
			$room["RoomStatusAfterH12"] = $row["RoomStatusAfterH12"];			
			$room["Floor_Label"] = $row["Floor_Label"];
			$room["Floor_Id"] = $row["Floor_Id"];
			$room["LinkSP"] = $row["LinkSP"];
			$room["Date_created"] = $row["Date_created"];
			$room["is_litBebe"] = $row["is_litBebe"];
			$room["is_porteOuverte"] = $row["is_porteOuverte"];
			$room["is_porteFermee"] = $row["is_porteFermee"];
			$room["is_canapeOuvert"] = $row["is_canapeOuvert"];
			$room["is_canapeFerme"] = $row["is_canapeFerme"];
			$room["is_litItalienne"] = $row["is_litItalienne"];
			$room["is_cadeauChocolat"] = $row["is_cadeauChocolat"];
			$room["is_cadeauChampagne"] = $row["is_cadeauChampagne"];
			$room["is_cadeauFleur"] = $row["is_cadeauFleur"];
			array_push($rooms, $room); 
		}
		echo json_encode($rooms);
	} else {
		$error["succes"] = false;
		$error["message"] = "Aucune chambre propre et occupée";
		// echo no users JSON
		echo json_encode($error);
	}
	deconnection_bdd($bdd);
}

function getDetailsRoom($Room_num ){
		$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM datacsv WHERE id='".$Room_num."'  ORDER BY id ASC") or die(mysqli_error($bdd));

	// check for empty result
	if (mysqli_num_rows($result) > 0) {
		// looping through all results
		$rooms = array();
		 
		while( $row = mysqli_fetch_array($result) ) {
			//$employe = getEmploye_id($row["EMP_ID"]);
			$room["id"] = $row["id"];
			$room["room_id"] = $row["room_id"];
			$room["room_num"] = $row["room_num"];
			$room["HXXType"] = $row["HXXType"];
			$room["ResidentOrGuest"] = $row["ResidentOrGuest"];
			$room["Etat"] = $row["Etat"];			
			$room["Lign_date"] = $row["Lign_date"];
			$room["PassedNights"] = $row["PassedNights"];
			$room["RemainingNights"] = $row["RemainingNights"];
			$room["StayStatus"] = $row["StayStatus"];
			$room["RoomStatusAfterH12"] = $row["RoomStatusAfterH12"];			
			$room["Floor_Label"] = $row["Floor_Label"];
			$room["Floor_Id"] = $row["Floor_Id"];
			$room["LinkSP"] = $row["LinkSP"];
			$room["Date_created"] = $row["Date_created"];
			$room["is_litBebe"] = $row["is_litBebe"];
			$room["is_porteOuverte"] = $row["is_porteOuverte"];
			$room["is_porteFermee"] = $row["is_porteFermee"];
			$room["is_canapeOuvert"] = $row["is_canapeOuvert"];
			$room["is_canapeFerme"] = $row["is_canapeFerme"];
			$room["is_litItalienne"] = $row["is_litItalienne"];
			$room["is_cadeauChocolat"] = $row["is_cadeauChocolat"];
			$room["is_cadeauChampagne"] = $row["is_cadeauChampagne"];
			$room["is_cadeauFleur"] = $row["is_cadeauFleur"];
			array_push($rooms, $room); 
		}
		echo json_encode($rooms);
	} else {
		$error["succes"] = false;
		$error["message"] = "Aucune chambre propre et occupée";
		// echo no users JSON
		echo json_encode($error);
	}
	deconnection_bdd($bdd);
}

function getRoomsOccupieDirty(){
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM datacsv WHERE Etat='OCC-Sal'ORDER BY id ASC") or die(mysqli_error($bdd));

	// check for empty result
	if (mysqli_num_rows($result) > 0) {
		// looping through all results
		$rooms = array();
		 
		while( $row = mysqli_fetch_array($result) ) {
			//$employe = getEmploye_id($row["EMP_ID"]);
			$room["id"] = $row["id"];
			$room["room_id"] = $row["room_id"];
			$room["room_num"] = $row["room_num"];
			$room["HXXType"] = $row["HXXType"];
			$room["ResidentOrGuest"] = $row["ResidentOrGuest"];
			$room["Etat"] = $row["Etat"];			
			$room["Lign_date"] = $row["Lign_date"];
			$room["PassedNights"] = $row["PassedNights"];
			$room["RemainingNights"] = $row["RemainingNights"];
			$room["StayStatus"] = $row["StayStatus"];
			$room["RoomStatusAfterH12"] = $row["RoomStatusAfterH12"];			
			$room["Floor_Label"] = $row["Floor_Label"];
			$room["Floor_Id"] = $row["Floor_Id"];
			$room["LinkSP"] = $row["LinkSP"];
			$room["Date_created"] = $row["Date_created"];
			$room["is_litBebe"] = $row["is_litBebe"];
			$room["is_porteOuverte"] = $row["is_porteOuverte"];
			$room["is_porteFermee"] = $row["is_porteFermee"];
			$room["is_canapeOuvert"] = $row["is_canapeOuvert"];
			$room["is_canapeFerme"] = $row["is_canapeFerme"];
			$room["is_litItalienne"] = $row["is_litItalienne"];
			$room["is_cadeauChocolat"] = $row["is_cadeauChocolat"];
			$room["is_cadeauChampagne"] = $row["is_cadeauChampagne"];
			$room["is_cadeauFleur"] = $row["is_cadeauFleur"];
			array_push($rooms, $room); 
		}
		echo json_encode($rooms);
	} else {
		$error["succes"] = false;
		$error["message"] = "Aucune chambre sale et occupée";
		// echo no users JSON
		echo json_encode($error);
	}
	deconnection_bdd($bdd);
}

function getRoomsFreeDirty(){
//function getTousEmployes_par_type($type){
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM datacsv WHERE Etat='LIB-Sal'ORDER BY id ASC") or die(mysqli_error($bdd));

	// check for empty result
	if (mysqli_num_rows($result) > 0) {
		// looping through all results
		$rooms = array();
		 
		while( $row = mysqli_fetch_array($result) ) {
			//$employe = getEmploye_id($row["EMP_ID"]);
			$room["id"] = $row["id"];
			$room["room_id"] = $row["room_id"];
			$room["room_num"] = $row["room_num"];
			$room["HXXType"] = $row["HXXType"];
			$room["ResidentOrGuest"] = $row["ResidentOrGuest"];
			$room["Etat"] = $row["Etat"];			
			$room["Lign_date"] = $row["Lign_date"];
			$room["PassedNights"] = $row["PassedNights"];
			$room["RemainingNights"] = $row["RemainingNights"];
			$room["StayStatus"] = $row["StayStatus"];
			$room["RoomStatusAfterH12"] = $row["RoomStatusAfterH12"];			
			$room["Floor_Label"] = $row["Floor_Label"];
			$room["Floor_Id"] = $row["Floor_Id"];
			$room["LinkSP"] = $row["LinkSP"];
			$room["Date_created"] = $row["Date_created"];
			$room["is_litBebe"] = $row["is_litBebe"];
			$room["is_porteOuverte"] = $row["is_porteOuverte"];
			$room["is_porteFermee"] = $row["is_porteFermee"];
			$room["is_canapeOuvert"] = $row["is_canapeOuvert"];
			$room["is_canapeFerme"] = $row["is_canapeFerme"];
			$room["is_litItalienne"] = $row["is_litItalienne"];
			$room["is_cadeauChocolat"] = $row["is_cadeauChocolat"];
			$room["is_cadeauChampagne"] = $row["is_cadeauChampagne"];
			$room["is_cadeauFleur"] = $row["is_cadeauFleur"];
			array_push($rooms, $room); 
		}
		echo json_encode($rooms);
	} else {
		$error["succes"] = false;
		$error["message"] = "Aucune chambre sale et libre";
		// echo no users JSON
		echo json_encode($error);
	}
	deconnection_bdd($bdd);
}

function getRoomsFreeClean(){
//function getTousEmployes_par_type($type){
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM datacsv WHERE Etat='LIB-Prp'ORDER BY id ASC") or die(mysqli_error($bdd));

	// check for empty result
	if (mysqli_num_rows($result) > 0) {
		// looping through all results
		$rooms = array();
		 
		while( $row = mysqli_fetch_array($result) ) {
			//$employe = getEmploye_id($row["EMP_ID"]);
			$room["id"] = $row["id"];
			$room["room_id"] = $row["room_id"];
			$room["room_num"] = $row["room_num"];
			$room["HXXType"] = $row["HXXType"];
			$room["ResidentOrGuest"] = $row["ResidentOrGuest"];
			$room["Etat"] = $row["Etat"];			
			$room["Lign_date"] = $row["Lign_date"];
			$room["PassedNights"] = $row["PassedNights"];
			$room["RemainingNights"] = $row["RemainingNights"];
			$room["StayStatus"] = $row["StayStatus"];
			$room["RoomStatusAfterH12"] = $row["RoomStatusAfterH12"];			
			$room["Floor_Label"] = $row["Floor_Label"];
			$room["Floor_Id"] = $row["Floor_Id"];
			$room["LinkSP"] = $row["LinkSP"];
			$room["Date_created"] = $row["Date_created"];
			$room["is_litBebe"] = $row["is_litBebe"];
			$room["is_porteOuverte"] = $row["is_porteOuverte"];
			$room["is_porteFermee"] = $row["is_porteFermee"];
			$room["is_canapeOuvert"] = $row["is_canapeOuvert"];
			$room["is_canapeFerme"] = $row["is_canapeFerme"];
			$room["is_litItalienne"] = $row["is_litItalienne"];
			$room["is_cadeauChocolat"] = $row["is_cadeauChocolat"];
			$room["is_cadeauChampagne"] = $row["is_cadeauChampagne"];
			$room["is_cadeauFleur"] = $row["is_cadeauFleur"];
			array_push($rooms, $room); 
		}
		echo json_encode($rooms);
	} else {
		$error["succes"] = false;
		$error["message"] = "Aucune chambre propre et libre";
		// echo no users JSON
		echo json_encode($error);
	}
	deconnection_bdd($bdd);
}
function getRoomsHS(){
		$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM datacsv WHERE Etat='HS-Sal' ORDER BY id ASC") or die(mysqli_error($bdd));

	// check for empty result
	if (mysqli_num_rows($result) > 0) {
		// looping through all results
		$rooms = array();
		 
		while( $row = mysqli_fetch_array($result) ) {
			$room["id"] = $row["id"];
			$room["room_id"] = $row["room_id"];
			$room["room_num"] = $row["room_num"];
			$room["HXXType"] = $row["HXXType"];
			$room["ResidentOrGuest"] = $row["ResidentOrGuest"];
			$room["Etat"] = $row["Etat"];			
			$room["Lign_date"] = $row["Lign_date"];
			$room["PassedNights"] = $row["PassedNights"];
			$room["RemainingNights"] = $row["RemainingNights"];
			$room["StayStatus"] = $row["StayStatus"];
			$room["RoomStatusAfterH12"] = $row["RoomStatusAfterH12"];			
			$room["Floor_Label"] = $row["Floor_Label"];
			$room["Floor_Id"] = $row["Floor_Id"];
			$room["LinkSP"] = $row["LinkSP"];
			$room["Date_created"] = $row["Date_created"];
			$room["is_litBebe"] = $row["is_litBebe"];
			$room["is_porteOuverte"] = $row["is_porteOuverte"];
			$room["is_porteFermee"] = $row["is_porteFermee"];
			$room["is_canapeOuvert"] = $row["is_canapeOuvert"];
			$room["is_canapeFerme"] = $row["is_canapeFerme"];
			$room["is_litItalienne"] = $row["is_litItalienne"];
			$room["is_cadeauChocolat"] = $row["is_cadeauChocolat"];
			$room["is_cadeauChampagne"] = $row["is_cadeauChampagne"];
			$room["is_cadeauFleur"] = $row["is_cadeauFleur"];
			array_push($rooms, $room); 
		}
		echo json_encode($rooms);
	} else {
		$error["succes"] = false;
		$error["message"] = "Aucune chambre HS";
		// echo no users JSON
		echo json_encode($error);
	}
	deconnection_bdd($bdd);
}



function  update_Etat_Room_Num($Room_num ,$Etat){	     

	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$date =(new \DateTime())->format('Y-m-d');	
	$result = $bdd->query("UPDATE chambresaffectees
						  SET etat='".$Etat."'						   
						  WHERE room_num='".$Room_num."' AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));
						  
	deconnection_bdd($bdd);	
}

function update_OptionsLitBebe_Room_Num($Room_num, $is_litBebe){
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$date =(new \DateTime())->format('Y-m-d');	

	$result = $bdd->query("UPDATE chambresaffectees
						  SET is_litBebe='".$is_litBebe."'						   
						  WHERE room_num='".$Room_num."' AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));
}

/*******************************************************************************************
* ----------------  Fonctions pour la modification des états des chambres ---------------- *
********************************************************************************************/

// --- Annoncer une chambre propre --- //
function updateRoom_clean($Room_num ,$Etat ){

		if($Etat == 'LIB-Sal') 	{ $Etat = "LIB-Prp";}
		if($Etat == 'OCC-Sal') 	{ $Etat = "OCC-Prp";}
		if($Etat == 'HS-Sal')  	{ $Etat = "LIB-Prp";}
		
		if($Etat == 'LIB-Prp-Priority') {$Etat = "LIB-Prp-Priority";}
		if($Etat == 'OCC-Prp-Priority') {$Etat = "OCC-Prp-Priority";}
		if($Etat == 'LIB-Sal-Priority') {$Etat = "LIB-Prp-Priority";}
		if($Etat == 'OCC-Sal-Priority') {$Etat = "OCC-Prp-Priority";} 

		if($Etat == 'LIB-Prp-ISSUE') {$Etat = "LIB-Prp-ISSUE";}
		if($Etat == 'OCC-Prp-ISSUE') {$Etat = "OCC-Prp-ISSUE";}
		if($Etat == 'LIB-Sal-ISSUE') {$Etat = "LIB-Prp-ISSUE";}
		if($Etat == 'OCC-Sal-ISSUE') {$Etat = "OCC-Prp-ISSUE";}

		if($Etat == 'LIB-Prp-ISSUE-Priority') {$Etat = "LIB-Prp-ISSUE-Priority";}
		if($Etat == 'OCC-Prp-ISSUE-Priority') {$Etat = "OCC-Prp-ISSUE-Priority";}
		if($Etat == 'LIB-Sal-ISSUE-Priority') {$Etat = "LIB-Prp-ISSUE-Priority";}
		if($Etat == 'OCC-Sal-ISSUE-Priority') {$Etat = "OCC-Prp-ISSUE-Priority";}

		if($Etat == 'HS-Sal') { $Etat = "LIB-Prp";}
		if($Etat == 'HS-Sal-Priority') {$Etat = "LIB-Prp-Priority";}
		if($Etat == 'HS-Sal-ISSUE') {$Etat = "LIB-Prp-ISSUE";}
		if($Etat == 'HS-Sal-ISSUE-Priority') {$Etat = "LIB-Prp-ISSUE-Priority";}

		if($Etat == 'LIB-Sal-Checked') 	{ $Etat = "LIB-Prp-Checked";}
		if($Etat == 'OCC-Sal-Checked') 	{ $Etat = "OCC-Prp-Checked";}
		
		if($Etat == 'LIB-Sal-Priority-Checked') {$Etat = "LIB-Prp-Priority-Checked";}
		if($Etat == 'OCC-Sal-Priority-Checked') {$Etat = "OCC-Prp-Priority-Checked";} 

		if($Etat == 'LIB-Sal-ISSUE-Checked') {$Etat = "LIB-Prp-ISSUE-Checked";}
		if($Etat == 'OCC-Sal-ISSUE-Checked') {$Etat = "OCC-Prp-ISSUE-Checked";}

		if($Etat == 'LIB-Sal-ISSUE-Priority-Checked') {$Etat = "LIB-Prp-ISSUE-Priority-Checked";}
		if($Etat == 'OCC-Sal-ISSUE-Priority-Checked') {$Etat = "OCC-Prp-ISSUE-Priority-Checked";}

		if($Etat == 'HS-Sal-Checked') { $Etat = "HS-Sal-Checked";}
		if($Etat == 'HS-Sal-Priority-Checked') {$Etat = "HS-Sal-Priority-Checked";}
		if($Etat == 'HS-Sal-ISSUE-Checked') {$Etat = "HS-Sal-ISSUE-Checked";}
		if($Etat == 'HS-Sal-ISSUE-Priority-Checked') {$Etat = "HS-Sal-ISSUE-Priority-Checked";}

	//update_Etat_Room_Num($Room_num ,$Etat);	
	$date =(new \DateTime())->format('Y-m-d');
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);

	$result = $bdd->query("UPDATE datacsv
						  SET Etat='".$Etat."'						   
						  WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

	$resultAffectees = $bdd->query("UPDATE chambresaffectees
						  SET etat='".$Etat."'						   
						  WHERE room_num='".$Room_num."'  AND date_created='".$date."'  ORDER BY id  ASC") or die(mysqli_error($bdd));

	
	if ( $bdd->affected_rows > 0 ) {			
		return true;
	}else{	
		return false;
	}
	deconnection_bdd($bdd);
}

// --- Annoncer une chambre sale --- //
function updateRoom_dirty($Room_num ,$Etat ){

		if($Etat == 'LIB-Prp') { $Etat = "LIB-Sal";}
		if($Etat == 'OCC-Prp') { $Etat = "OCC-Sal";}
		if($Etat == 'HS-Sal')  { $Etat = "HS-Sal";}

		if($Etat == 'LIB-Prp-Priority') {$Etat = "LIB-Sal-Priority";}
		if($Etat == 'LIB-Sal-Priority') {$Etat = "LIB-Sal-Priority";}
		if($Etat == 'OCC-Prp-Priority') {$Etat = "OCC-Sal-Priority";}
		if($Etat == 'OCC-Sal-Priority') {$Etat = "OCC-Sal-Priority";} 

		if($Etat == 'LIB-Prp-ISSUE') {$Etat = "LIB-Sal-ISSUE";}
		if($Etat == 'LIB-Sal-ISSUE') {$Etat = "LIB-Sal-ISSUE";}
		if($Etat == 'OCC-Prp-ISSUE') {$Etat = "OCC-Sal-ISSUE";}
		if($Etat == 'OCC-Sal-ISSUE') {$Etat = "OCC-Sal-ISSUE";}

		if($Etat == 'LIB-Prp-ISSUE-Priority') {$Etat = "LIB-Sal-ISSUE-Priority";}
		if($Etat == 'OCC-Prp-ISSUE-Priority') {$Etat = "OCC-Sal-ISSUE-Priority";}
		if($Etat == 'LIB-Sal-ISSUE-Priority') {$Etat = "LIB-Sal-ISSUE-Priority";}
		if($Etat == 'OCC-Sal-ISSUE-Priority') {$Etat = "OCC-Sal-ISSUE-Priority";}

		if($Etat == 'HS-Sal') { $Etat = "HS-Sal";}
		if($Etat == 'HS-Sal-Priority') {$Etat = "HS-Sal-Priority";}
		if($Etat == 'HS-Sal-ISSUE-') {$Etat = "HS-Sal-ISSUE";}
		if($Etat == 'HS-Sal-ISSUE-Priority') {$Etat = "HS-Sal-ISSUE-Priority";}

		if($Etat == 'LIB-Prp-Checked') 	{ $Etat = "LIB-Sal-Checked";}
		if($Etat == 'OCC-Prp-Checked') 	{ $Etat = "OCC-Sal-Checked";}
		
		if($Etat == 'LIB-Prp-Priority-Checked') {$Etat = "LIB-Sal-Priority-Checked";}
		if($Etat == 'OCC-Prp-Priority-Checked') {$Etat = "OCC-Sal-Priority-Checked";}

		if($Etat == 'LIB-Prp-ISSUE-Checked') {$Etat = "LIB-Sal-ISSUE-Checked";}
		if($Etat == 'OCC-Prp-ISSUE-Checked') {$Etat = "OCC-Sal-ISSUE-Checked";}

		if($Etat == 'LIB-Prp-ISSUE-Priority-Checked') {$Etat = "LIB-Sal-ISSUE-Priority-Checked";}
		if($Etat == 'OCC-Prp-ISSUE-Priority-Checked') {$Etat = "OCC-Sal-ISSUE-Priority-Checked";}

		if($Etat == 'HS-Sal-Checked') { $Etat = "HS-Sal-Checked";}
		if($Etat == 'HS-Sal-Priority-Checked') {$Etat = "HS-Sal-Priority-Checked";}
		if($Etat == 'HS-Sal-ISSUE-Checked') {$Etat = "HS-Sal-ISSUE-Checked";}
		if($Etat == 'HS-Sal-ISSUE-Priority-Checked') {$Etat = "HS-Sal-ISSUE-Priority-Checked";}

	//update_Etat_Room_Num($Room_num ,$Etat);	
	$date =(new \DateTime())->format('Y-m-d');
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("UPDATE datacsv
						  SET Etat='".$Etat."'						   
						  WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

	$resultAffectees = $bdd->query("UPDATE chambresaffectees
						  SET etat='".$Etat."'						   
						  WHERE room_num='".$Room_num."'  AND date_created='".$date."'  ORDER BY id  ASC") or die(mysqli_error($bdd));
	
	if ( $bdd->affected_rows > 0 ) {		
		return true;
	}else{
		return false;
	}
	deconnection_bdd($bdd);
}

// --- Annoncer une chambre hors service --- //
function  updateRoom_HS($Room_num ,$Etat ){
		
	if($Etat == 'LIB-Prp') { $Etat = "HS-Sal";}
	if($Etat == 'LIB-Prp-Priority') {$Etat = "HS-Sal";}
	if($Etat == 'LIB-Prp-ISSUE') {$Etat = "HS-Sal-ISSUE";}
	if($Etat == 'LIB-Prp-ISSUE-Priority') {$Etat = "HS-Sal-ISSUE-Priority";}
	if($Etat == 'LIB-Sal') { $Etat = "HS-Sal";}
	if($Etat == 'LIB-Sal-Priority') {$Etat = "HS-Sal";}
	if($Etat == 'LIB-Sal-ISSUE') {$Etat = "HS-Sal-ISSUE";}
	if($Etat == 'LIB-Sal-ISSUE-Priority') {$Etat = "HS-Sal-ISSUE-Priority";}

	if($Etat == 'OCC-Prp') { $Etat = "HS-Sal";}
	if($Etat == 'OCC-Prp-Priority') {$Etat = "HS-Sal-ISSUE-Priority";}
	if($Etat == 'OCC-Prp-ISSUE') {$Etat = "HS-Sal-ISSUE";}
	if($Etat == 'OCC-Prp-ISSUE-Priority') {$Etat = "HS-Sal-ISSUE-Priority";}
	if($Etat == 'OCC-Sal-ISSUE') {$Etat = "HS-Sal-ISSUE";}
	if($Etat == 'OCC-Sal') { $Etat = "HS-Sal";}
	if($Etat == 'OCC-Sal-Priority') {$Etat = "HS-Sal-Priority";}
	if($Etat == 'OCC-Sal-ISSUE-Priority') {$Etat = "HS-Sal-ISSUE-Priority";}

	if($Etat == 'HS-Sal')  { $Etat = "HS-Sal";}

	if($Etat == 'LIB-Prp-Checked') 	{ $Etat = "HS-Sal-Checked";}
	if($Etat == 'LIB-Sal-Checked') 	{ $Etat = "HS-Sal-Checked";}
	if($Etat == 'OCC-Prp-Checked') 	{ $Etat = "HS-Sal-Checked";}
	if($Etat == 'OCC-Sal-Checked') 	{ $Etat = "HS-Sal-Checked";}
		
	if($Etat == 'LIB-Prp-Priority-Checked') {$Etat = "HS-Sal-Priority-Checked";}
	if($Etat == 'OCC-Prp-Priority-Checked') {$Etat = "HS-Sal-Priority-Checked";}
	if($Etat == 'LIB-Sal-Priority-Checked') {$Etat = "HS-Sal-Priority-Checked";}
	if($Etat == 'OCC-Sal-Priority-Checked') {$Etat = "HS-Sal-Priority-Checked";} 

	if($Etat == 'LIB-Prp-ISSUE-Checked') {$Etat = "HS-Sal-ISSUE-Checked";}
	if($Etat == 'OCC-Prp-ISSUE-Checked') {$Etat = "HS-Sal-ISSUE-Checked";}
	if($Etat == 'LIB-Sal-ISSUE-Checked') {$Etat = "HS-Sal-ISSUE-Checked";}
	if($Etat == 'OCC-Sal-ISSUE-Checked') {$Etat = "HS-Sal-ISSUE-Checked";}

	if($Etat == 'LIB-Prp-ISSUE-Priority-Checked') {$Etat = "HS-Sal-ISSUE-Priority";}
	if($Etat == 'OCC-Prp-ISSUE-Priority-Checked') {$Etat = "HS-Sal-ISSUE-Priority";}
	if($Etat == 'LIB-Sal-ISSUE-Priority-Checked') {$Etat = "HS-Sal-ISSUE-Priority";}
	if($Etat == 'OCC-Sal-ISSUE-Priority-Checked') {$Etat = "HS-Sal-ISSUE-Priority";}

	//update_Etat_Room_Num($Room_num ,$Etat);	
	$date =(new \DateTime())->format('Y-m-d');
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("UPDATE datacsv
						  SET Etat='".$Etat."'						   
						  WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

	$resultAffectees = $bdd->query("UPDATE chambresaffectees
						  SET etat='".$Etat."'						   
						  WHERE room_num='".$Room_num."'  AND date_created='".$date."'  ORDER BY id  ASC") or die(mysqli_error($bdd));
	
	if ( $bdd->affected_rows > 0 ) {		
		return true;
	}else{
		return false;
	}
	deconnection_bdd($bdd);
}	

// --- Annoncer un problème dans une chambre --- //
function  updateRoom_Issue($Room_num ,$Etat ){

		if($Etat == 'LIB-Prp') { $Etat = "LIB-Prp-ISSUE";}
		if($Etat == 'LIB-Sal') { $Etat = "LIB-Sal-ISSUE";}
		if($Etat == 'LIB-Prp-Priority') {$Etat = "LIB-Prp-ISSUE-Priority";}
		if($Etat == 'LIB-Sal-Priority') {$Etat = "LIB-Sal-ISSUE-Priority";}

		if($Etat == 'OCC-Prp') { $Etat = "OCC-Prp-ISSUE";}
		if($Etat == 'OCC-Sal') { $Etat = "OCC-Sal-ISSUE";}
		if($Etat == 'OCC-Prp-Priority') {$Etat = "OCC-Prp-ISSUE-Priority";}
		if($Etat == 'OCC-Sal-Priority') {$Etat = "OCC-Sal-ISSUE-Priority";}
		
		if($Etat == 'HS-Sal') { $Etat = "HS-Sal-ISSUE";}
		if($Etat == 'HS-Sal-Priority') {$Etat = "HS-Sal-ISSUE-Priority";}

		if($Etat == 'LIB-Prp-Checked') 	{ $Etat = "LIB-Prp-ISSUE-Checked";}
		if($Etat == 'LIB-Sal-Checked') 	{ $Etat = "LIB-Sal-ISSUE-Checked";}
		if($Etat == 'OCC-Prp-Checked') 	{ $Etat = "OCC-Prp-ISSUE-Checked";}
		if($Etat == 'OCC-Sal-Checked') 	{ $Etat = "OCC-Sal-ISSUE-Checked";}
		
		if($Etat == 'LIB-Prp-Priority-Checked') {$Etat = "LIB-Prp-ISSUE-Priority-Checked";}
		if($Etat == 'OCC-Prp-Priority-Checked') {$Etat = "OCC-Prp-ISSUE-Priority-Checked";}
		if($Etat == 'LIB-Sal-Priority-Checked') {$Etat = "LIB-Sal-ISSUE-Priority-Checked";}
		if($Etat == 'OCC-Sal-Priority-Checked') {$Etat = "OCC-Sal-ISSUE-Priority-Checked";} 

		if($Etat == 'HS-Sal-Checked') { $Etat = "HS-Sal-ISSUE-Checked";}
		if($Etat == 'HS-Sal-Priority-Checked') {$Etat = "HS-Sal-ISSUE-Priority-Checked";}

	//update_Etat_Room_Num($Room_num ,$Etat);	
	$date =(new \DateTime())->format('Y-m-d');
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("UPDATE datacsv
						  SET Etat='".$Etat."'						   
						  WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

	$resultAffectees = $bdd->query("UPDATE chambresaffectees
						  SET etat='".$Etat."'						   
						  WHERE room_num='".$Room_num."'  AND date_created='".$date."'  ORDER BY id  ASC") or die(mysqli_error($bdd));
	
	if ( $bdd->affected_rows > 0 ) {		
		return true;
	}else{
		return false;
	}
	deconnection_bdd($bdd);
}	

// --- Annoncer un problème résolu dans une chambre --- //
function  updateRoom_noneIssue($Room_num ,$Etat ){

	if($Etat == 'LIB-Prp-ISSUE') { $Etat = "LIB-Prp";}
	if($Etat == 'LIB-Sal-ISSUE') { $Etat = "LIB-Sal";}
	if($Etat == 'LIB-Prp-ISSUE-Priority') {$Etat = "LIB-Prp-Priority";}
	if($Etat == 'LIB-Sal-ISSUE-Priority') {$Etat = "LIB-Sal-Priority";}

	if($Etat == 'OCC-Prp-ISSUE') { $Etat = "OCC-Prp";}
	if($Etat == 'OCC-Sal-ISSUE') { $Etat = "OCC-Sal";}
	if($Etat == 'OCC-Prp-ISSUE-Priority') {$Etat = "OCC-Prp-Priority";}
	if($Etat == 'OCC-Sal-ISSUE-Priority') {$Etat = "OCC-Sal-Priority";}

	if($Etat == 'LIB-Prp-ISSUE-Checked') 	{ $Etat = "LIB-Prp-Checked";}
	if($Etat == 'LIB-Sal-ISSUE-Checked') 	{ $Etat = "LIB-Sal-Checked";}
	if($Etat == 'OCC-Prp-ISSUE-Checked') 	{ $Etat = "OCC-Prp-Checked";}
	if($Etat == 'OCC-Sal-ISSUE-Checked') 	{ $Etat = "OCC-Sal-Checked";}
		
	if($Etat == 'LIB-Prp-ISSUE-Priority-Checked') {$Etat = "LIB-Prp-Priority-Checked";}
	if($Etat == 'OCC-Prp-ISSUE-Priority-Checked') {$Etat = "OCC-Prp-Priority-Checked";}
	if($Etat == 'LIB-Sal-ISSUE-Priority-Checked') {$Etat = "LIB-Sal-Priority-Checked";}
	if($Etat == 'OCC-Sal-ISSUE-Priority-Checked') {$Etat = "OCC-Sal-Priority-Checked";} 
		
	if($Etat == 'HS-Sal-ISSUE') { $Etat = "HS-Sal";}
	if($Etat == 'HS-Sal-ISSUE-Priority') {$Etat = "HS-Sal-Priority";}
	if($Etat == 'HS-Sal-ISSUE-Checked') { $Etat = "HS-Sal-Checked";}
	if($Etat == 'HS-Sal-ISSUE-Priority-Checked') {$Etat = "HS-Sal-Priority-Checked";}

 	//update_Etat_Room_Num($Room_num ,$Etat);	
	$date =(new \DateTime())->format('Y-m-d');
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("UPDATE datacsv
						  SET Etat='".$Etat."'						   
						  WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

	$resultAffectees = $bdd->query("UPDATE chambresaffectees
						  SET etat='".$Etat."'						   
						  WHERE room_num='".$Room_num."'  AND date_created='".$date."'  ORDER BY id  ASC") or die(mysqli_error($bdd));
	
	if ( $bdd->affected_rows > 0 ) {		
		return true;
	}else{
		return false;
	}
	deconnection_bdd($bdd);
}

// --- Annoncer une chambre prioritaire --- //
function  updateRoom_Priority($Room_num ,$Etat ){
	
	if($Etat == 'LIB-Prp') { $Etat = "LIB-Prp-Priority";}
	if($Etat == 'LIB-Sal') { $Etat = "LIB-Sal-Priority";}
	if($Etat == 'LIB-Prp-ISSUE') {$Etat = "LIB-Prp-ISSUE-Priority";}
	if($Etat == 'LIB-Sal-ISSUE') {$Etat = "LIB-Sal-ISSUE-Priority";}

	if($Etat == 'OCC-Prp') { $Etat = "OCC-Prp-Priority";}
	if($Etat == 'OCC-Sal') { $Etat = "OCC-Sal-Priority";}
	if($Etat == 'OCC-Prp-ISSUE') {$Etat = "OCC-Prp-ISSUE-Priority";}
	if($Etat == 'OCC-Sal-ISSUE') {$Etat = "OCC-Sal-ISSUE-Priority";}

	if($Etat == 'LIB-Prp-Checked') 	{ $Etat = "LIB-Prp-Priority-Checked";}
	if($Etat == 'LIB-Sal-Checked') 	{ $Etat = "LIB-Sal-Priority-Checked";}
	if($Etat == 'OCC-Prp-Checked') 	{ $Etat = "OCC-Prp-Priority-Checked";}
	if($Etat == 'OCC-Sal-Checked') 	{ $Etat = "OCC-Sal-Priority-Checked";}

	if($Etat == 'LIB-Prp-ISSUE-Checked') {$Etat = "LIB-Prp-ISSUE-Priority-Checked";}
	if($Etat == 'OCC-Prp-ISSUE-Checked') {$Etat = "OCC-Prp-ISSUE-Priority-Checked";}
	if($Etat == 'LIB-Sal-ISSUE-Checked') {$Etat = "LIB-Sal-ISSUE-Priority-Checked";}
	if($Etat == 'OCC-Sal-ISSUE-Checked') {$Etat = "OCC-Sal-ISSUE-Priority-Checked";}

	if($Etat == 'HS-Sal-Checked') { $Etat = "HS-Sal-Priority-Checked";}
	if($Etat == 'HS-Sal-ISSUE-Checked') {$Etat = "HS-Sal-ISSUE-Priority-Checked";}
	if($Etat == 'HS-Sal') { $Etat = "HS-Sal-Priority";}
	if($Etat == 'HS-Sal-ISSUE') {$Etat = "HS-Sal-ISSUE-Priority";}
		
    //update_Etat_Room_Num($Room_num ,$Etat);
	$date =(new \DateTime())->format('Y-m-d');
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);

	$result = $bdd->query("UPDATE datacsv
						  SET Etat='".$Etat."'						   
						  WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

	$resultAffectees = $bdd->query("UPDATE chambresaffectees
						  SET etat='".$Etat."'						   
						  WHERE room_num='".$Room_num."'  AND date_created='".$date."'  ORDER BY id  ASC") or die(mysqli_error($bdd));
	
	if ( $bdd->affected_rows > 0 ) {	
		return true;
	}else{
		return false;
	}
	deconnection_bdd($bdd);
}

// --- Annoncer une chambre qui n'est plus prioritaire --- //
function  updateRoom_nonePriority($Room_num ,$Etat ){

	if($Etat == 'LIB-Prp-Priority') { $Etat = "LIB-Prp";}
	if($Etat == 'LIB-Sal-Priority') { $Etat = "LIB-Sal";}
	if($Etat == 'LIB-Prp-ISSUE-Priority') {$Etat = "LIB-Prp";}
	if($Etat == 'LIB-Sal-ISSUE-Priority') {$Etat = "LIB-Sal";}

	if($Etat == 'OCC-Prp-Priority') { $Etat = "OCC-Prp";}
	if($Etat == 'OCC-Sal-Priority') { $Etat = "OCC-Sal";}
	if($Etat == 'OCC-Prp-ISSUE-Priority') {$Etat = "OCC-Prp-ISSUE";}
	if($Etat == 'OCC-Sal-ISSUE-Priority') {$Etat = "OCC-Sal-ISSUE";}

	if($Etat == 'LIB-Prp-Priority-Checked') 	{ $Etat = "LIB-Prp-Checked";}
	if($Etat == 'LIB-Sal-Priority-Checked') 	{ $Etat = "LIB-Sal-Checked";}
	if($Etat == 'OCC-Prp-Priority-Checked') 	{ $Etat = "OCC-Prp-Checked";}
	if($Etat == 'OCC-Sal-Priority-Checked') 	{ $Etat = "OCC-Sal-Checked";}

	if($Etat == 'LIB-Prp-ISSUE-Priority-Checked') {$Etat = "LIB-Prp-ISSUE-Checked";}
	if($Etat == 'OCC-Prp-ISSUE-Priority-Checked') {$Etat = "OCC-Prp-ISSUE-Checked";}
	if($Etat == 'LIB-Sal-ISSUE-Priority-Checked') {$Etat = "LIB-Sal-ISSUE-Checked";}
	if($Etat == 'OCC-Sal-ISSUE-Priority-Checked') {$Etat = "OCC-Sal-ISSUE-Checked";}

	if($Etat == 'HS-Sal-Priority') { $Etat = "HS-Sal";}
	if($Etat == 'HS-Sal-ISSUE-Priority') {$Etat = "HS-Sal-ISSUE";}
	if($Etat == 'HS-Sal-Priority-Checked-Checked') { $Etat = "HS-Sal-Checked";}
	if($Etat == 'HS-Sal-ISSUE-Priority-Checked-Checked') {$Etat = "HS-Sal-ISSUE-Checked";}

	//update_Etat_Room_Num($Room_num ,$Etat);	
	$date =(new \DateTime())->format('Y-m-d');
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("UPDATE datacsv
						  SET Etat='".$Etat."'						   
						  WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

	$resultAffectees = $bdd->query("UPDATE chambresaffectees
						  SET etat='".$Etat."'						   
						  WHERE room_num='".$Room_num."'  AND date_created='".$date."'  ORDER BY id  ASC") or die(mysqli_error($bdd));
	
	if ( $bdd->affected_rows > 0 ) {		
		return true;
	}else{
		return false;
	}
	deconnection_bdd($bdd);
}	

// --- Annoncer une chambre vérifiée par la gouvernante --- //
function updateRoom_gouvernanteChecked($Room_num ,$Etat ){

	if($Etat == 'LIB-Prp') 	{ $Etat = "LIB-Prp-Checked";}
	if($Etat == 'LIB-Sal') 	{ $Etat = "LIB-Sal-Checked";}
	if($Etat == 'OCC-Prp') 	{ $Etat = "OCC-Prp-Checked";}
	if($Etat == 'OCC-Sal') 	{ $Etat = "OCC-Sal-Checked";}
	
	if($Etat == 'LIB-Prp-Priority') {$Etat = "LIB-Prp-Priority-Checked";}
	if($Etat == 'OCC-Prp-Priority') {$Etat = "OCC-Prp-Priority-Checked";}
	if($Etat == 'LIB-Sal-Priority') {$Etat = "LIB-Sal-Priority-Checked";}
	if($Etat == 'OCC-Sal-Priority') {$Etat = "OCC-Sal-Priority-Checked";} 

	if($Etat == 'LIB-Prp-ISSUE') {$Etat = "LIB-Prp-ISSUE-Checked";}
	if($Etat == 'OCC-Prp-ISSUE') {$Etat = "OCC-Prp-ISSUE-Checked";}
	if($Etat == 'LIB-Sal-ISSUE') {$Etat = "LIB-Sal-ISSUE-Checked";}
	if($Etat == 'OCC-Sal-ISSUE') {$Etat = "OCC-Sal-ISSUE-Checked";}

	if($Etat == 'LIB-Prp-ISSUE-Priority') {$Etat = "LIB-Prp-ISSUE-Priority-Checked";}
	if($Etat == 'OCC-Prp-ISSUE-Priority') {$Etat = "OCC-Prp-ISSUE-Priority-Checked";}
	if($Etat == 'LIB-Sal-ISSUE-Priority') {$Etat = "LIB-Sal-ISSUE-Priority-Checked";}
	if($Etat == 'OCC-Sal-ISSUE-Priority') {$Etat = "OCC-Sal-ISSUE-Priority-Checked";}

	if($Etat == 'HS-Sal') { $Etat = "HS-Sal-Checked";}
	if($Etat == 'HS-Sal-Priority') {$Etat = "HS-Sal-Priority-Checked";}
	if($Etat == 'HS-Sal-ISSUE') {$Etat = "HS-Sal-ISSUE-Checked";}
	if($Etat == 'HS-Sal-ISSUE-Priority') {$Etat = "HS-Sal-ISSUE-Priority-Checked";}

	//update_Etat_Room_Num($Room_num ,$Etat);	
	$date =(new \DateTime())->format('Y-m-d');
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("UPDATE datacsv
						  SET Etat='".$Etat."'						   
						  WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

	$resultAffectees = $bdd->query("UPDATE chambresaffectees
						  SET etat='".$Etat."'						   
						  WHERE room_num='".$Room_num."'   AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	
	if ( $bdd->affected_rows > 0 ) {		
		return true;
	}else{	
		return false;
	}
	deconnection_bdd($bdd);
}

// --- Annoncer une chambre qui n'est plus vérifiée par la gouvernante --- //
function updateRoom_noneGouvernanteChecked($Room_num ,$Etat ){

	if($Etat == 'LIB-Prp-Checked') 	{ $Etat = "LIB-Prp";}
	if($Etat == 'LIB-Sal-Checked') 	{ $Etat = "LIB-Sal";}
	if($Etat == 'OCC-Prp-Checked') 	{ $Etat = "OCC-Prp";}
	if($Etat == 'OCC-Sal-Checked') 	{ $Etat = "OCC-Sal";}
	
	if($Etat == 'LIB-Prp-Priority-Checked') {$Etat = "LIB-Prp-Priority";}
	if($Etat == 'OCC-Prp-Priority-Checked') {$Etat = "OCC-Prp-Priority";}
	if($Etat == 'LIB-Sal-Priority-Checked') {$Etat = "LIB-Sal-Priority";}
	if($Etat == 'OCC-Sal-Priority-Checked') {$Etat = "OCC-Sal-Priority";} 

	if($Etat == 'LIB-Prp-ISSUE-Checked') {$Etat = "LIB-Prp-ISSUE";}
	if($Etat == 'OCC-Prp-ISSUE-Checked') {$Etat = "OCC-Prp-ISSUE";}
	if($Etat == 'LIB-Sal-ISSUE-Checked') {$Etat = "LIB-Sal-ISSUE";}
	if($Etat == 'OCC-Sal-ISSUE-Checked') {$Etat = "OCC-Sal-ISSUE";}

	if($Etat == 'LIB-Prp-ISSUE-Priority-Checked') {$Etat = "LIB-Prp-ISSUE-Priority";}
	if($Etat == 'OCC-Prp-ISSUE-Priority-Checked') {$Etat = "OCC-Prp-ISSUE-Priority";}
	if($Etat == 'LIB-Sal-ISSUE-Priority-Checked') {$Etat = "LIB-Sal-ISSUE-Priority";}
	if($Etat == 'OCC-Sal-ISSUE-Priority-Checked') {$Etat = "OCC-Sal-ISSUE-Priority";}

	if($Etat == 'HS-Sal-Checked') { $Etat = "HS-Sal";}
	if($Etat == 'HS-Sal-Priority-Checked') {$Etat = "HS-Sal-Priority";}
	if($Etat == 'HS-Sal-ISSUE-Checked') {$Etat = "HS-Sal-ISSUE";}
	if($Etat == 'HS-Sal-ISSUE-Priority-Checked') {$Etat = "HS-Sal-ISSUE-Priority";}

	//update_Etat_Room_Num($Room_num ,$Etat);	
	$date =(new \DateTime())->format('Y-m-d');
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("UPDATE datacsv
						  SET Etat='".$Etat."'						   
						  WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

	$resultAffectees = $bdd->query("UPDATE chambresaffectees
						  SET etat='".$Etat."'						   
						  WHERE room_num='".$Room_num."'  AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	
	if ( $bdd->affected_rows > 0 ) {		
		return true;
	}else{	
		return false;
	}
	deconnection_bdd($bdd);
}

/*******************************************************************************************
* -----------------------  Fonctions pour les options des chambres ----------------------- *
********************************************************************************************/

// Option : lit de bébé
function update_room_litbebe($Room_num ,$is_litBebe ){	
	$date =(new \DateTime())->format('Y-m-d');
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
		
	if ($is_litBebe == true) {
		//update_OptionsLitBebe_Room_Num($Room_num ,$is_litBebe);	
		$result = $bdd->query("UPDATE datacsv
					  	SET is_litBebe='0'						   
						WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

		$resultAffectees = $bdd->query("UPDATE chambresaffectees
					  	SET is_litBebe='0'						   
						WHERE room_num='".$Room_num."'  AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	}elseif ($is_litBebe == false) {
		//update_OptionsLitBebe_Room_Num($Room_num, $is_litBebe);
		$result = $bdd->query("UPDATE datacsv
						SET is_litBebe='1'						   
						WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

		$resultAffectees = $bdd->query("UPDATE chambresaffectees
					  	SET is_litBebe='1'						   
						WHERE room_num='".$Room_num."' AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	}

	if ( $bdd->affected_rows > 0 ) {		
		return true;
	}else{	
		return false;
	}
	deconnection_bdd($bdd);
}

// Option : porte ouverte
function update_room_porteOuverte($Room_num ,$is_porteOuverte ){
	//update_Etat_Room_Num($Room_num ,$is_porteOuverte);	
	$date =(new \DateTime())->format('Y-m-d');
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
		
	if ($is_porteOuverte == true) {
		$result = $bdd->query("UPDATE datacsv
					  	SET is_porteOuverte='0'						   
						WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

		$resultAffectees = $bdd->query("UPDATE chambresaffectees
					  SET is_porteOuverte='0'						   
					  WHERE room_num='".$Room_num."' AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	}elseif ($is_porteOuverte == false) {
		$result = $bdd->query("UPDATE datacsv
						SET is_porteOuverte='1'						   
						WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

		$resultAffectees = $bdd->query("UPDATE chambresaffectees
					  SET is_porteOuverte='1'						   
					  WHERE room_num='".$Room_num."' AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	}

	if ( $bdd->affected_rows > 0 ) {		
		return true;
	}else{	
		return false;
	}
	deconnection_bdd($bdd);
}

// Option : porte fermée
function update_room_porteFermee($Room_num ,$is_porteFermee ){
	//update_Etat_Room_Num($Room_num ,$is_porteFermee);	
	$date =(new \DateTime())->format('Y-m-d');
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
		
	if ($is_porteFermee == true) {
		$result = $bdd->query("UPDATE datacsv
					  	SET is_porteFermee='0'						   
						WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

		$resultAffectees = $bdd->query("UPDATE chambresaffectees
					  SET is_porteFermee='0'						   
					  WHERE room_num='".$Room_num."' AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	}elseif ($is_porteFermee == false) {
		$result = $bdd->query("UPDATE datacsv
						SET is_porteFermee='1'						   
						WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

		$resultAffectees = $bdd->query("UPDATE chambresaffectees
					  SET is_porteFermee='1'						   
					  WHERE room_num='".$Room_num."' AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	}

	if ( $bdd->affected_rows > 0 ) {		
		return true;
	}else{	
		return false;
	}
	deconnection_bdd($bdd);
}

// Option : canapé ouvert
function update_room_canapeOuvert($Room_num ,$is_canapeOuvert ){
	//update_Etat_Room_Num($Room_num ,$is_canapeOuvert);	
	$date =(new \DateTime())->format('Y-m-d');
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
		
	if ($is_canapeOuvert == true) {
		$result = $bdd->query("UPDATE datacsv
					  	SET is_canapeOuvert='0'						   
						WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

		$resultAffectees = $bdd->query("UPDATE chambresaffectees
					  SET is_canapeOuvert='0'						   
					  WHERE room_num='".$Room_num."' AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	}elseif ($is_canapeOuvert == false) {
		$result = $bdd->query("UPDATE datacsv
						SET is_canapeOuvert='1'						   
						WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

		$resultAffectees = $bdd->query("UPDATE chambresaffectees
					  SET is_canapeOuvert='1'						   
					  WHERE room_num='".$Room_num."' AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	}

	if ( $bdd->affected_rows > 0 ) {		
		return true;
	}else{	
		return false;
	}
	deconnection_bdd($bdd);
}

// Option : canapé fermé
function update_room_canapeFerme($Room_num ,$is_canapeFerme ){
	//update_Etat_Room_Num($Room_num ,$is_canapeFerme);	
	$date =(new \DateTime())->format('Y-m-d');
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
		
	if ($is_canapeFerme == true) {
		$result = $bdd->query("UPDATE datacsv
					  	SET is_canapeFerme='0'						   
						WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

		$resultAffectees = $bdd->query("UPDATE chambresaffectees
					  SET is_canapeFerme='0'						   
					  WHERE room_num='".$Room_num."' AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));

	}elseif ($is_canapeFerme == false) {
		$result = $bdd->query("UPDATE datacsv
						SET is_canapeFerme='1'						   
						WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

		$resultAffectees = $bdd->query("UPDATE chambresaffectees
					  SET is_canapeFerme='1'						   
					  WHERE room_num='".$Room_num."' AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	}

	if ( $bdd->affected_rows > 0 ) {		
		return true;
	}else{	
		return false;
	}
	deconnection_bdd($bdd);
}

// Option : Lit à l'italienne
function update_room_litItalienne($Room_num ,$is_litItalienne ){
	//update_Etat_Room_Num($Room_num ,$Etat);	
	$date =(new \DateTime())->format('Y-m-d');
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
		
	if ($is_litItalienne == true) {
		$result = $bdd->query("UPDATE datacsv
					  	SET is_litItalienne='0'						   
						WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

		$resultAffectees = $bdd->query("UPDATE chambresaffectees
					  SET is_litItalienne='0'						   
					  WHERE room_num='".$Room_num."' AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));

	}elseif ($is_litItalienne == false) {
		$result = $bdd->query("UPDATE datacsv
						SET is_litItalienne='1'						   
						WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

		$resultAffectees = $bdd->query("UPDATE chambresaffectees
					  SET is_litItalienne='1'						   
					  WHERE room_num='".$Room_num."' AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	}

	if ( $bdd->affected_rows > 0 ) {		
		return true;
	}else{	
		return false;
	}
	deconnection_bdd($bdd);
}

// Option : Cadeau chocolat
function update_room_cadeauChocolat($Room_num ,$is_cadeauChocolat ){
	//update_Etat_Room_Num($Room_num ,$Etat);	
	$date =(new \DateTime())->format('Y-m-d');
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
		
	if ($is_cadeauChocolat == true) {
		$result = $bdd->query("UPDATE datacsv
					  	SET is_cadeauChocolat='0'						   
						WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

		$resultAffectees = $bdd->query("UPDATE chambresaffectees
					  SET is_cadeauChocolat='0'						   
					  WHERE room_num='".$Room_num."' AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));

	}elseif ($is_cadeauChocolat == false) {
		$result = $bdd->query("UPDATE datacsv
						SET is_cadeauChocolat='1'						   
						WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

		$resultAffectees = $bdd->query("UPDATE chambresaffectees
					  SET is_cadeauChocolat='1'						   
					  WHERE room_num='".$Room_num."' AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	}

	if ( $bdd->affected_rows > 0 ) {		
		return true;
	}else{	
		return false;
	}
	deconnection_bdd($bdd);
}

// Option : cadeau champagne
function update_room_cadeauChampagne($Room_num ,$is_cadeauChampagne ){
	//update_Etat_Room_Num($Room_num ,$Etat);	
	$date =(new \DateTime())->format('Y-m-d');
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	
	if ($is_cadeauChampagne == true) {
		$result = $bdd->query("UPDATE datacsv
					  	SET is_cadeauChampagne='0'						   
						WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

		$resultAffectees = $bdd->query("UPDATE chambresaffectees
					  SET is_cadeauChampagne='0'						   
					  WHERE room_num='".$Room_num."' AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));

	}elseif ($is_cadeauChampagne == false) {
		$result = $bdd->query("UPDATE datacsv
						SET is_cadeauChampagne='1'						   
						WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

		$resultAffectees = $bdd->query("UPDATE chambresaffectees
					  SET is_cadeauChampagne='1'						   
					  WHERE room_num='".$Room_num."' AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	}

	if ( $bdd->affected_rows > 0 ) {		
		return true;
	}else{	
		return false;
	}
	deconnection_bdd($bdd);
}

// Option : cadeau fleurs
function update_room_cadeauFleur($Room_num ,$is_cadeauFleur ){
	//update_Etat_Room_Num($Room_num ,$Etat);	
	$date =(new \DateTime())->format('Y-m-d');
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	
	if ($is_cadeauFleur == true) {
		$result = $bdd->query("UPDATE datacsv
					  SET is_cadeauFleur='0'						   
					  WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

		$resultAffectees = $bdd->query("UPDATE chambresaffectees
					  SET is_cadeauFleur='0'						   
					  WHERE room_num='".$Room_num."' AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	}elseif ($is_cadeauFleur == false) {
		$result = $bdd->query("UPDATE datacsv
					  SET is_cadeauFleur='1'						   
					  WHERE room_num='".$Room_num."' ORDER BY id  ASC") or die(mysqli_error($bdd));

		$resultAffectees = $bdd->query("UPDATE chambresaffectees
					  SET is_cadeauFleur='1'						   
					  WHERE room_num='".$Room_num."' AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	} 
	
	if ( $bdd->affected_rows > 0 ) {		
		return true;
	}else{	
		return false;
	}
	deconnection_bdd($bdd);
}

?>