<?php
header("Access-Control-Allow-Origin:*");
require('fonctions_rooms.php');

//http://stackoverflow.com/questions/18382740/cors-not-working-php
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }
 
    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
 
        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         
 
        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
 
        exit(0);
    }
 
  $postdata = file_get_contents("php://input");
  $json_data = json_decode($postdata);
 
 foreach($json_data->rooms as $value){
	 
           $room_id            = $value->room_id;
		   $room_num           = $value->room_num;
		   $HXXType            = $value->HXXType;
		   $ResidentOrGuest    = $value->ResidentOrGuest;
		   $Etat               = $value->Etat;
		   $Lign_date          = $value->Lign_date;
		   $PassedNights       = $value->PassedNights;
		   $RemainingNights    = $value->RemainingNights;
		   $StayStatus         = $value->StayStatus;
		   $RoomStatusAfterH12 = $value->RoomStatusAfterH12;
		   $Floor_Label        = $value->Floor_Label;
		   $Floor_Id           = $value->Floor_Id;
		   $LinkSP             = $value->LinkSP;

           $is_litBebe         = $value->is_litBebe;
           $is_porteOuverte    = $value->is_porteOuverte;
           $is_porteFermee     = $value->is_porteFermee;
           $is_canapeOuvert    = $value->is_canapeOuvert;
           $is_canapeFerme     = $value->is_canapeFerme;
           $is_litItalienne    = $value->is_litItalienne;
           $is_cadeauChocolat  = $value->is_cadeauChocolat;
           $is_cadeauChampagne = $value->is_cadeauChampagne;
           $is_cadeauFleur     = $value->is_cadeauFleur;
		   addRooms($room_id, $room_num, $HXXType, $ResidentOrGuest, $Etat, $Lign_date , $PassedNights,$RemainingNights, $StayStatus, $RoomStatusAfterH12 ,$Floor_Label,$Floor_Id,$LinkSP, $is_litBebe, $is_porteOuverte, $is_porteFermee, $is_canapeOuvert, $is_canapeFerme, $is_litItalienne, $is_cadeauChocolat, $is_cadeauChampagne, $is_cadeauFleur);	
   
}
  
?>