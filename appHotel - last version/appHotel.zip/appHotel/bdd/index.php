<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="csv.css">
		<title>Housekeeping - Importez votre CSV</title>
	</head>
	<body>
		<div>
			<span>Choisissez le fichier CSV à importer</span>
			<form action="" method="POST" enctype="multipart/form-data">
        		<input type="file" name="image" />
        		<input type="submit"/>
      		</form>
		</div>
		
	</body>
</html>