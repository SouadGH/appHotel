<?php
header("Access-Control-Allow-Origin:*");
require('variables_utilisateur.php');
/* ----------------------------------------------------------------
   ------------------------- UTILISATEURS ----------------------------
   ---------------------------------------------------------------- */
   
/***************************** GET & LIST *****************************************/
function getUtilisateur_ID($id, $bdd){
	$result = $bdd->query("SELECT * FROM ".NOM_TABLE." 
						   WHERE ".COL_ID."=".$id) or die(mysqli_error($bdd));
	
	if (mysqli_num_rows($result) == 1) {
		$row = mysqli_fetch_array($result);
		$utilisateur["id"] = $row[COL_ID];
		$utilisateur["uuid"] = $row[COL_UUID];
		$utilisateur["nom_utilisateur"] = $row[COL_NOM_UTILISATEUR];
		$utilisateur["mot_de_passe"] = $row[COL_MOT_DE_PASSE];
		$utilisateur["nom"] = $row[COL_NOM];
		$utilisateur["prenom"] = $row[COL_PRENOM];
		$utilisateur["sexe"] = $row[COL_SEXE];
		$utilisateur["telephone"] = $row[COL_TELEPHONE];
		$utilisateur["is_gouvernante"] = $row[COL_IS_GOUVERNANTE]==0 ? false : true;
		$utilisateur["is_reception"] = $row[COL_IS_RECEPTION]==0 ? false : true;
		$utilisateur["is_femme_chambre"] = $row[COL_IS_FEMME_CHAMBRE]==0 ? false : true;
		return $utilisateur;
	}
	return null;
}

function getUtilisateur_TELEPHONE($telephone, $bdd){
	$result = $bdd->query("SELECT ".COL_ID." FROM ".NOM_TABLE." 
						   WHERE ".COL_TELEPHONE."=".$telephone) or die(mysqli_error($bdd));
	
	if (mysqli_num_rows($result) == 1) {
		$row = mysqli_fetch_array($result);
		$utilisateur = getUtilisateur_ID($row[COL_ID], $bdd);
		return $utilisateur;
	}
	return null;
}
function getUtilisateur_MOTDEPASSE($mot_de_passe, $bdd){
	$result = $bdd->query("SELECT ".COL_ID." FROM ".NOM_TABLE." 
						   WHERE ".COL_MOT_DE_PASSE."=".$mot_de_passe) or die(mysqli_error($bdd));
	
	if (mysqli_num_rows($result) == 1) {
		$row = mysqli_fetch_array($result);
		$utilisateur = getUtilisateur_ID($row[COL_ID], $bdd);
		return $utilisateur;
	}
	return null;
}
/***************************** ENCODE JSON *****************************************/
function getUtilisateur_JSON($utilisateur){
	echo json_encode($utilisateur);
}
?>