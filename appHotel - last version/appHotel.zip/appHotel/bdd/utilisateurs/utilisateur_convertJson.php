<?php
header("Access-Control-Allow-Origin:*");
require('../connexion_bdd.php');
require('fonctions_utilisateur.php');

/* ----------------------------------------------------------------
   ------------------------- TRANSFERTS ----------------------------
   ---------------------------------------------------------------- */

if( isset($_GET['get']) ){
	$utilisateur = null;
   if(  isset($_GET['id']) ){
		$id = $_GET['id'];
		$utilisateur = getUtilisateur_ID($id, $BDD_GLOBALE);
	}else if(  isset($_GET['telephone']) ){
		$telephone = "".$_GET['telephone'];
		$utilisateur = getUtilisateur_TELEPHONE($telephone, $BDD_GLOBALE);
	}else if(  isset($_GET['mot_de_passe']) ){
		$mot_de_passe = "".$_GET['mot_de_passe'];
		$utilisateur = getUtilisateur_MOTDEPASSE($mot_de_passe, $BDD_GLOBALE);
	}
	getUtilisateur_JSON($utilisateur);
}


deconnection_bdd($BDD_GLOBALE);
//
?>