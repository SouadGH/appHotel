<?php
header("Access-Control-Allow-Origin:*");

define('NOM_TABLE', "utilisateur");
define('COL_ID', "UTI_ID");
define('COL_UUID', "Uti_uuid");
define('COL_NOM_UTILISATEUR', "Uti_nom_utilisateur");
define('COL_MOT_DE_PASSE', "Uti_mot_de_passe");
define('COL_NOM', "Uti_nom");
define('COL_PRENOM', "Uti_prenom");
define('COL_SEXE', "Uti_sexe");
define('COL_TELEPHONE', "Uti_telephone");
define('COL_IS_GOUVERNANTE', "Uti_isGouvernante");
define('COL_IS_RECEPTION', "Uti_isReception");
define('COL_IS_FEMME_CHAMBRE', "Uti_isFemmeChambre");
?>