<?php
header("Access-Control-Allow-Origin:*");
require('connexion_bdd.php');

   if(isset($_FILES['image'])){
      $errors= array();
      $file_name = $_FILES['image']['name'];
      $file_size =$_FILES['image']['size'];
      $file_tmp =$_FILES['image']['tmp_name'];
      $file_type=$_FILES['image']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
      
      $extensions= array("jpeg","jpg","png","csv");
      
      if(in_array($file_ext,$extensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
	  echo "<pre>";
	  // Test si le fichier CSV du jour est déja uploader
	 $exist_upload = uploadExist();
	 if( $exist_upload==true){
		 var_dump("Le Fichier CSV est déja uploadé !!!!");
	 }
	 else{
		 
		 var_dump("Le fichier CSV du jour n'est pas encore uploadé !!!!");
	 }
	  
     echo "</pre>";
      
      if(empty($errors)==true){
		
         move_uploaded_file($file_tmp,"dataCSV/".$file_name);
		 //convert file csv to json
		$tab = convertCSVtoJSON("dataCSV/".$file_name);
		if( sizeof($tab)>0){
			 //remplir la BD 
             addCSVtoDB($tab);
			 //déplacer le fichier vers l'archive
             copy("dataCSV/".$file_name,"dataCSV_Archive/".$file_name);
			 unlink("dataCSV/".$file_name);
		}else{
			  echo "le fichier CSV est vide";
		}
				 
         echo "Insertion du fichier CSV avec Success";
      }else{
         print_r($errors);
      }
   }
   //convertir le fichier CSV to JSON
 function  convertCSVtoJSON($file){
	   
$filename = $file;

// The nested array to hold all the arrays
$the_big_array = []; 

// Open the file for reading
if (($h = fopen("{$filename}", "r")) !== FALSE) 
{
  // Each line in the file is converted into an individual array that we call $data
  // The items of the array are comma separated
  while (($data = fgetcsv($h, 1000, ";")) !== FALSE) 
  {
    // Each individual array is being pushed into the nested array
    $the_big_array[] = $data;		
  }

  // Close the file
  fclose($h);
  return $the_big_array;
}

// Display the code in a readable format
echo "<pre>";
//var_dump($the_big_array);
echo "</pre>";
   }

function   addCSVtoDB($tab){
	$tab_new = []; 
	$taille = sizeof($tab);
    
	//tableau sans l'entête
    for( $i = 1 ; $i < $taille ; $i++)
    $tab_new[$i-1] = $tab[$i] ;

	foreach(  $tab_new as $value){			
		   $room_id            =  $value[0];
		   $room_num           =  $value[1];
		   $HXXType            = $value[2];
		   $ResidentOrGuest    = $value[3];
		   $Etat               =  $value[4];
		   $Lign_date          = $value[5];
		   $PassedNights       = $value[6];
		   $RemainingNights    = $value[7];
		   $StayStatus         = $value[8];
		   $RoomStatusAfterH12 =  $value[9];
		   $Floor_Label        =  $value[10];
		   $Floor_Id           =  $value[11];
		   $LinkSP             = $value[12];		
		
		   addRooms($room_id, $room_num, $HXXType, $ResidentOrGuest, $Etat, $Lign_date , $PassedNights,$RemainingNights, $StayStatus, $RoomStatusAfterH12 ,$Floor_Label,$Floor_Id,$LinkSP  );	
		
}
}

function  addRooms($room_id, $room_num, $HXXType, $ResidentOrGuest, $Etat, $Lign_date , $PassedNights,$RemainingNights, $StayStatus, $RoomStatusAfterH12 ,$Floor_Label,$Floor_Id,$LinkSP  ){

	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);	
	$date =(new \DateTime())->format('Y-m-d H:i:s');
	
    $secteur  = getSecteurId($room_num);
	 $result = $bdd->query("INSERT INTO datacsv (room_id, room_num,HXXType,ResidentOrGuest,Etat,Lign_date,PassedNights,RemainingNights,StayStatus,RoomStatusAfterH12,Floor_Label,Floor_Id,LinkSP,secteur,Date_created)
	 VALUES(
	 '".$room_id."',
	 '".$room_num."',
	 '".$HXXType."',
	 '".$ResidentOrGuest."',
	 '".$Etat."',
	 '".$Lign_date."',
	 '".$PassedNights."',
	 '".$RemainingNights."',
	 '".$StayStatus."',
	 '".$RoomStatusAfterH12."',
	 '".$Floor_Label."',
	 '".$Floor_Id."',
	 '".$LinkSP."',
	 '".$secteur."',
	 '".$date."')") or die(mysqli_error($bdd));

	if ( $bdd->affected_rows > 0 ) {	
	 //echo "Insertion dans la tablde de datacsv avec succes !!";
		return true;
	}else{
		echo "Erreur d'insertion dans la tablde de datacsv  !!";
		return false;
	}
	
	deconnection_bdd($bdd);
}

function getSecteurId($room_num) {	
	
		$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
		
		$result = $bdd->query("SELECT * FROM secteur WHERE room_num='".$room_num."' ORDER BY id_secteur ASC") or die(mysqli_error($bdd));
	if (mysqli_num_rows($result) > 0) {
		$row = mysqli_fetch_array($result);
		$secteur = $row["libelle_secteur"];
	
		return $secteur;
	}else{
		$error["succes"] = false;
		$error["message"] = "Ce numero de chambre na pas de secteur";
	
		return null;
	}
	deconnection_bdd($bdd);
}

function uploadExist(){
	$date =(new \DateTime())->format('Y-m-d');
	
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	
	$result = $bdd->query("SELECT *  FROM datacsv WHERE Date_created = '".$date."' ORDER BY id ASC") or die(mysqli_error($bdd));
			
	if (mysqli_num_rows($result) > 0) {
	
		return true;
	} else {
				
		return null;
	}
	deconnection_bdd($bdd);
}
?>
<!--
<html>
   <body>
      
      <form action="" method="POST" enctype="multipart/form-data">
         <input type="file" name="image" />
         <input type="submit"/>
      </form>
      
   </body>
</html>
-->