﻿<?php
header("Access-Control-Allow-Origin:*");
require('../connexion_bdd.php');

function  deleteRoomsAffected(){
	$date =(new \DateTime())->format('Y-m-d');
	
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("DELETE   FROM chambresaffectees WHERE date_created='".$date."' ORDER BY id ASC") or die(mysqli_error($bdd));

if ( $bdd->affected_rows > 0 ) {	
	 echo json_encode ("Suppression du planning du jour avec succes !!");
		return true;
	}else{
		echo json_encode ("Erreur de suppression du planning du jour  !!");
		return false;
	}
	
	deconnection_bdd($bdd);	
/*	var_dump($result);


	if ( $result ) {	
         echo json_encode("Suppression du planning du jour avec succes !!");	
		// echo "Suppression du planning du jour avec succes !!";
		//return true;
	}else{
		
		$error["succes"] = false;
		$error["message"] = "Erreur de suppression du planning du jour  !!";
		// echo no users JSON
		echo json_encode($error);
		
		//echo "Erreur de suppression du planning du jour  !!";
		//return false;
	}
	deconnection_bdd($bdd);*/
}

function  getRoomsAffected(){
	$date =(new \DateTime())->format('Y-m-d');
	
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM chambresaffectees WHERE  date_created='".$date."'  ORDER BY id ASC") or die(mysqli_error($bdd));

	// check for empty result
	if (mysqli_num_rows($result) > 0) {
		// looping through all results
		$rooms = array();
		 
		while( $row = mysqli_fetch_array($result) ) {
			//$employe = getEmploye_id($row["EMP_ID"]);
			$room["id"] = $row["id"];
			$room["id_FM"] = $row["id_FM"];
			$room["room_num"] = $row["room_num"];
			$room["etage"] = $row["etage"];			
			$room["etat"] = $row["etat"];
			$room["secteur"] = $row["secteur"];
			$room["date_created"] = $row["date_created"];

			$room["is_litBebe"] = $row["is_litBebe"];
			$room["is_porteOuverte"] = $row["is_porteOuverte"];
			$room["is_porteFermee"] = $row["is_porteFermee"];
			$room["is_canapeOuvert"] = $row["is_canapeOuvert"];
			$room["is_canapeFerme"] = $row["is_canapeFerme"];
			$room["is_litItalienne"] = $row["is_litItalienne"];
			$room["is_cadeauChocolat"] = $row["is_cadeauChocolat"];
			$room["is_cadeauChampagne"] = $row["is_cadeauChampagne"];
			$room["is_cadeauFleur"] = $row["is_cadeauFleur"];
			array_push($rooms, $room); 
		}
		echo json_encode($rooms);
		return $rooms;
	} else {
		$error["succes"] = false;
		$error["message"] = "Aucune chambre affectee aujourd'hui ";
		// echo no users JSON
		echo json_encode($error);
		return null;
	}
	deconnection_bdd($bdd);		
}

function getRoomsNotAffected(){
	$date =(new \DateTime())->format('Y-m-d');
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT room_num,Etat,Floor_Label,secteur,Date_created,is_litBebe, is_porteOuverte, is_porteFermee, is_canapeOuvert, is_canapeFerme, is_litItalienne, is_cadeauChocolat, is_cadeauChampagne, is_cadeauFleur FROM datacsv WHERE room_num NOT IN
	(SELECT room_num FROM chambresaffectees WHERE  date_created='".$date."')  ORDER BY id ASC") or die(mysqli_error($bdd));

// check for empty result
	if (mysqli_num_rows($result) > 0) {
		// looping through all results
		$rooms = array();
		 
		while( $row = mysqli_fetch_array($result) ) {
			$room["id"] ='0';
			$room["id_FM"] ='0';
			$room["room_num"] = $row["room_num"];						
			$room["etat"] = $row["Etat"];
			$room["etage"] = $row["Floor_Label"];						
			$room["secteur"] = $row["secteur"];
			$room["date_created"] = $row["Date_created"];
			$room["is_litBebe"] = $row["is_litBebe"];

			$room["is_porteOuverte"] = $row["is_porteOuverte"];
			$room["is_porteFermee"] = $row["is_porteFermee"];
			$room["is_canapeOuvert"] = $row["is_canapeOuvert"];
			$room["is_canapeFerme"] = $row["is_canapeFerme"];
			$room["is_litItalienne"] = $row["is_litItalienne"];
			$room["is_cadeauChocolat"] = $row["is_cadeauChocolat"];
			$room["is_cadeauChampagne"] = $row["is_cadeauChampagne"];
			$room["is_cadeauFleur"] = $row["is_cadeauFleur"];

			array_push($rooms, $room); 
		}
		echo json_encode($rooms);
		return $rooms;
	} else {
		$error["succes"] = false;
		$error["message"] = "Aucune chambre non affectée.";
		// echo no users JSON
		echo json_encode($error);
		return null;
	}
	deconnection_bdd($bdd);
	
	
	
}
function  getRoomsAffectedFDC($id_FM){
	$date =(new \DateTime())->format('Y-m-d');
	
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM chambresaffectees WHERE id_FM='".$id_FM."' AND date_created='".$date."'  ORDER BY id ASC") or die(mysqli_error($bdd));

	// check for empty result
	if (mysqli_num_rows($result) > 0) {
		// looping through all results
		$rooms = array();
		 
		while( $row = mysqli_fetch_array($result) ) {
			$room["id"] = $row["id"];
			$room["id_FM"] = $row["id_FM"];
			$room["room_num"] = $row["room_num"];
			$room["etage"] = $row["etage"];			
			$room["etat"] = $row["etat"];
			$room["secteur"] = $row["secteur"];
			$room["date_created"] = $row["date_created"];

			$room["is_litBebe"] = $row["is_litBebe"];
			$room["is_porteOuverte"] = $row["is_porteOuverte"];
			$room["is_porteFermee"] = $row["is_porteFermee"];
			$room["is_canapeOuvert"] = $row["is_canapeOuvert"];
			$room["is_canapeFerme"] = $row["is_canapeFerme"];
			$room["is_litItalienne"] = $row["is_litItalienne"];
			$room["is_cadeauChocolat"] = $row["is_cadeauChocolat"];
			$room["is_cadeauChampagne"] = $row["is_cadeauChampagne"];
			$room["is_cadeauFleur"] = $row["is_cadeauFleur"];
			array_push($rooms, $room); 
		}
		echo json_encode($rooms);
		return $rooms;
	} else {
		$error["succes"] = false;
		$error["message"] = "Aucune chambre affectee a cette FDC ";
		// echo no users JSON
		echo json_encode($error);
		return null;
	}
	deconnection_bdd($bdd);
	
}

function  getRoomsAffectedSecteurId($secteur){
	$date =(new \DateTime())->format('Y-m-d');
	
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM chambresaffectees WHERE secteur='".$secteur."' AND date_created='".$date."'  ORDER BY id ASC") or die(mysqli_error($bdd));

	// check for empty result
	if (mysqli_num_rows($result) > 0) {
		// looping through all results
		$rooms = array();
		 
		while( $row = mysqli_fetch_array($result) ) {
			$room["id"] = $row["id"];
			$room["id_FM"] = $row["id_FM"];
			$room["room_num"] = $row["room_num"];
			$room["etage"] = $row["etage"];			
			$room["etat"] = $row["etat"];
			$room["secteur"] = $row["secteur"];
			$room["date_created"] = $row["date_created"];

			$room["is_litBebe"] = $row["is_litBebe"];
			$room["is_porteOuverte"] = $row["is_porteOuverte"];
			$room["is_porteFermee"] = $row["is_porteFermee"];
			$room["is_canapeOuvert"] = $row["is_canapeOuvert"];
			$room["is_canapeFerme"] = $row["is_canapeFerme"];
			$room["is_litItalienne"] = $row["is_litItalienne"];
			$room["is_cadeauChocolat"] = $row["is_cadeauChocolat"];
			$room["is_cadeauChampagne"] = $row["is_cadeauChampagne"];
			$room["is_cadeauFleur"] = $row["is_cadeauFleur"];
			array_push($rooms, $room); 
		}
		echo json_encode($rooms);
		return $rooms;
	} else {
		$error["succes"] = false;
		$error["message"] = "Aucune chambre affectee a ce secteur ";
		// echo no users JSON
		echo json_encode($error);
		return null;
	}
	deconnection_bdd($bdd);
	
}

function  addRooms($room_id, $room_num, $HXXType, $ResidentOrGuest, $Etat, $Lign_date , $PassedNights,$RemainingNights, $StayStatus, $RoomStatusAfterH12 ,$Floor_Label,$Floor_Id,$LinkSP, $is_litBebe, $is_porteOuverte, $is_porteFermee, $is_canapeOuvert, $is_canapeFerme, $is_litItalienne, $is_cadeauChocolat, $is_cadeauChampagne, $is_cadeauFleur){

	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);	
	$date =(new \DateTime())->format('Y-m-d H:i:s');
	
    $secteur  = getSecteurId($room_num);
	 $result = $bdd->query("INSERT INTO datacsv (room_id, room_num,HXXType,ResidentOrGuest,Etat,Lign_date,PassedNights,RemainingNights,StayStatus,RoomStatusAfterH12,Floor_Label,Floor_Id,LinkSP,secteur,Date_created, is_litBebe, is_porteOuverte, is_porteFermee, is_canapeOuvert, is_canapeFerme, is_litItalienne, is_cadeauChocolat, is_cadeauChampagne, is_cadeauFleur)
	 VALUES(
	 '".$room_id."',
	 '".$room_num."',
	 '".$HXXType."',
	 '".$ResidentOrGuest."',
	 '".$Etat."',
	 '".$Lign_date."',
	 '".$PassedNights."',
	 '".$RemainingNights."',
	 '".$StayStatus."',
	 '".$RoomStatusAfterH12."',
	 '".$Floor_Label."',
	 '".$Floor_Id."',
	 '".$LinkSP."',
	 '".$secteur."',
	 '".$date."',

	 '".$is_litBebe."',
	 '".$is_porteOuverte."'
	 '".$is_porteFermee."'
	 '".$is_canapeOuvert."'
	 '".$is_canapeFerme."'
	 '".$is_litItalienne."'
	 '".$is_cadeauChocolat."'
	 '".$is_cadeauChampagne."'
	 '".$is_cadeauFleur."')") or die(mysqli_error($bdd));

	if ( $bdd->affected_rows > 0 ) {	
	 echo "Insertion dans la tablde de datacsv avec succes !!";
		return true;
	}else{
		echo "Erreur d'insertion dans la tablde de datacsv  !!";
		return false;
	}
	
	deconnection_bdd($bdd);
}

function  addRoomsAffected($id,$etage,$secteur){
	$date =(new \DateTime())->format('Y-m-d');
	//retourne toutes les chambres du meme etage
	//$roomsFloor = array();   	
	$roomsFloorSecteur	= getRooms_IdFloor_IdSecteur($etage,$secteur);	
	 foreach( $roomsFloorSecteur as $room) {
				   $etat   =  $room["Etat"] ;		  
		           $room_num   = $room["room_num"];
		           $is_litBebe = $room["is_litBebe"];
		           $is_porteOuverte = $room["is_porteOuverte"];
				   $is_porteFermee = $room["is_porteFermee"];
				   $is_canapeOuvert = $room["is_canapeOuvert"];
				   $is_canapeFerme = $room["is_canapeFerme"];
				   $is_litItalienne = $room["is_litItalienne"];
				   $is_cadeauChocolat = $room["is_cadeauChocolat"];
				   $is_cadeauChampagne = $room["is_cadeauChampagne"];
				   $is_cadeauFleur = $room["is_cadeauFleur"];
				   
				    //retourne le numero du setecur selon numero de la chambre		          
		
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);		

	$result = $bdd->query("INSERT INTO chambresaffectees (id_FM,room_num,etat,etage,secteur,date_created, is_litBebe, is_porteOuverte, is_porteFermee, is_canapeOuvert, is_canapeFerme, is_litItalienne, is_cadeauChocolat, is_cadeauChampagne, is_cadeauFleur)
	 VALUES(
	 '".$id."',
	 '".$room_num."',
	 '".$etat."',
	 '".$etage."',	
     '".$secteur."',	 
	 '".$date."',

	 '".$is_litBebe."',
	 '".$is_porteOuverte."',
	 '".$is_porteFermee."',
	 '".$is_canapeOuvert."',
	 '".$is_canapeFerme."',
	 '".$is_litItalienne."',
	 '".$is_cadeauChocolat."',
	 '".$is_cadeauChampagne."',
	 '".$is_cadeauFleur."')") or die(mysqli_error($bdd));
	 
	deconnection_bdd($bdd);
	}
}
function addRoomReaffected($id_FM,$rooms){
	$date =(new \DateTime())->format('Y-m-d');
	//retourne toutes les chambres du meme etage
	/*$roomsFloor = array();   	
	$roomsFloorSecteur	= getRooms_IdFloor_IdSecteur($etage,$secteur);	
	
	foreach($rooms as $room){
		  $room_num = $room->room_num;
		  $etage = $room->etage;
		  $secteur = $room->secteur;
		  $etat = = $room->etat;
		  addRoomReaffected($id_FM,$room_num,$etage,$secteur,$etat);		  
	  }*/
	
	 foreach( $rooms as $room) {
		  $room_num = $room->room_num;
		  $etage = $room->etage;
		  $secteur = $room->secteur;
		  $etat =  $room->etat;
			json_encode($room);	
				   
				    //retourne le numero du setecur selon numero de la chambre		          
		
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);		

	$result = $bdd->query("INSERT INTO chambresaffectees (id_FM,room_num,etat,etage,secteur,date_created, is_litBebe, is_porteOuverte, is_porteFermee, is_canapeOuvert, is_canapeFerme, is_litItalienne, is_cadeauChocolat, is_cadeauChampagne, is_cadeauFleur)
	 VALUES(
	 '".$id_FM."',
	 '".$room_num."',
	 '".$etat."',
	 '".$etage."',	
     '".$secteur."',	 
	 '".$date."',
	 '".$is_litBebe."',
	 '".$is_porteOuverte."',
	 '".$is_porteFermee."',
	 '".$is_canapeOuvert."',
	 '".$is_canapeFerme."',
	 '".$is_litItalienne."',
	 '".$is_cadeauChocolat."',
	 '".$is_cadeauChampagne."',
	 '".$is_cadeauFleur."')") or die(mysqli_error($bdd));
	 
	if ( $bdd->affected_rows > 0 ) {	
	 json_encode ("reaffectation  avec succes !!");
		//return true;
	}else{
		json_encode ("Erreur reaffectation  !!");
		//return false;
	}
	
	deconnection_bdd($bdd);
			  }
}
function getRoomsSecteurId($secteur){
		$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
		
		$result = $bdd->query("SELECT * FROM secteur WHERE libelle_secteur=".$secteur." ORDER BY id_secteur ASC") or die(mysqli_error($bdd));
	if (mysqli_num_rows($result) > 0) {
		$rooms =array();
		while( $row = mysqli_fetch_array($result) ) {
			$room["room_num"] = $row["room_num"];	
			array_push($rooms, $room); 
		}
		return $rooms;
		echo json_encode($rooms);
	} else {
		$error["succes"] = false;
		$error["message"] = "Il y a pas de femmes de chambre disponible dans cette hotel";
	
		echo json_encode($error);
		return null;
	}
	deconnection_bdd($bdd);
}
function getSecteurId($room_num) {	
	
		$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
		
		$result = $bdd->query("SELECT * FROM secteur WHERE room_num=".$room_num." ORDER BY id_secteur ASC") or die(mysqli_error($bdd));
	if (mysqli_num_rows($result) > 0) {
		$row = mysqli_fetch_array($result);
		$secteur = $row["libelle_secteur"];
			
				//echo json_encode($secteur);
		return $secteur;
	}else{
		$error["succes"] = false;
		$error["message"] = "Ce numero de chambre na pas de secteur";
		// echo no users JSON
		//echo json_encode($error);
		return null;
	}
	deconnection_bdd($bdd);
}

function getAllFemmesDeMenage(){

	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM femmedemenage	 WHERE  is_active='1' ORDER BY id ASC") or die(mysqli_error($bdd));

	// check for empty result
	if (mysqli_num_rows($result) > 0) {
		// looping through all results
		$femmes = array();
		 
		while( $row = mysqli_fetch_array($result) ) {
			$femme["id_FM"] = $row["id"];
			$femme["code"] = $row["code"];
			$femme["nom"] = $row["nom"];
			$femme["prenom"] = $row["prenom"];
			$femme["presence"] = $row["presence"];
			$femme["secteur"] = $row["secteur"];	
			$femme["etage"] = $row["etage"];
			$femme["is_active"] = $row["is_active"];			
			
			
			array_push($femmes, $femme); 
		}
		echo json_encode($femmes);
	} else {
		$error["succes"] = false;
		$error["message"] = "Il y a pas de femmes de chambre disponible dans cette hotel";
	
		echo json_encode($error);
	}
	deconnection_bdd($bdd);
}

function getAllFemmesDeMenage_Desactiver(){

	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM femmedemenage	 WHERE  is_active='0' ORDER BY id ASC") or die(mysqli_error($bdd));

	// check for empty result
	if (mysqli_num_rows($result) > 0) {
		// looping through all results
		$femmes = array();
		 
		while( $row = mysqli_fetch_array($result) ) {
			$femme["id_FM"] = $row["id"];
			$femme["code"] = $row["code"];
			$femme["nom"] = $row["nom"];
			$femme["prenom"] = $row["prenom"];
			$femme["presence"] = $row["presence"];
			$femme["secteur"] = $row["secteur"];	
			$femme["etage"] = $row["etage"];
			$femme["is_active"] = $row["is_active"];
			
			
			
			array_push($femmes, $femme); 
		}
		echo json_encode($femmes);
	} else {
		$error["succes"] = false;
		$error["message"] = "Il y a pas de femmes de chambre disponible dans cette hotel";
	
		echo json_encode($error);
	}
	deconnection_bdd($bdd);
}

function getFDC_Code($code){
	
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM femmedemenage where code='".$code."' ORDER BY id ASC") or die(mysqli_error($bdd));

	// check for empty result
	if (mysqli_num_rows($result) > 0) {
		// looping through all results
		
		 $femmes = array();
		while( $row = mysqli_fetch_array($result) ) {
			$femme["id_FM"] = $row["id"];
			$femme["code"] = $row["code"];
			$femme["nom"] = $row["nom"];
			$femme["prenom"] = $row["prenom"];
			$femme["presence"] = $row["presence"];
			$femme["secteur"] = $row["secteur"];	
			$femme["etage"] = $row["etage"];
			$femme["is_active"] = $row["is_active"];
			
           array_push($femmes, $femme); 
			
		}
		echo json_encode($femmes);
		//return $femme;
	} else {
		$error["succes"] = false;
		$error["message"] = "Il y a pas de femmes de chambre avec ce code";
	
		echo json_encode($error);
		//return null;
	}
	deconnection_bdd($bdd);
}

function getFemmesDeMenage_ID($id){

	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM femmedemenage WHERE id='".$id."'  ORDER BY id ASC") or die(mysqli_error($bdd));

	// check for empty result
	if (mysqli_num_rows($result) > 0) {
				 
		while( $row = mysqli_fetch_array($result) ) {
			$femme["id_FM"] = $row["id"];
			$femme["code"] = $row["code"];
			$femme["nom"] = $row["nom"];
			$femme["prenom"] = $row["prenom"];
			$femme["presence"] = $row["presence"];
			$femme["secteur"] = $row["secteur"];	
			$femme["etage"] = $row["etage"];
			$femme["is_active"] = $row["is_active"];
		}
		//echo json_encode($femme);
		return $femme;
	} else {
		$error["succes"] = false;
		$error["message"] = "Il y a pas de femmes de chambre avec cet ID ";
	
		//echo json_encode($error);
		return null;
	}
	deconnection_bdd($bdd);
}

function  getRooms_IdFloor_IdSecteur($id_floor,$secteur){
	
		$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM datacsv 	WHERE Floor_Label=".$id_floor." AND secteur=".$secteur." ORDER BY id ASC") or die(mysqli_error($bdd));

	// check for empty result
	if (mysqli_num_rows($result) > 0) {
		// looping through all results
		$rooms = array();
		 
		while( $row = mysqli_fetch_array($result) ) {
			
			$room["id"] = $row["id"];
			$room["room_id"] = $row["room_id"];
			$room["room_num"] = $row["room_num"];
			$room["HXXType"] = $row["HXXType"];
			$room["ResidentOrGuest"] = $row["ResidentOrGuest"];
			$room["Etat"] = $row["Etat"];			
			$room["Lign_date"] = $row["Lign_date"];
			$room["PassedNights"] = $row["PassedNights"];
			$room["RemainingNights"] = $row["RemainingNights"];
			$room["StayStatus"] = $row["StayStatus"];
			$room["RoomStatusAfterH12"] = $row["RoomStatusAfterH12"];			
			$room["Floor_Label"] = $row["Floor_Label"];
			$room["Floor_Id"] = $row["Floor_Id"];
			$room["LinkSP"] = $row["LinkSP"];
			$room["Date_created"] = $row["Date_created"];
			$room["is_litBebe"] = $row["is_litBebe"];
			$room["is_porteOuverte"] = $row["is_porteOuverte"];
			$room["is_porteFermee"] = $row["is_porteFermee"];
			$room["is_canapeOuvert"] = $row["is_canapeOuvert"];
			$room["is_canapeFerme"] = $row["is_canapeFerme"];
			$room["is_litItalienne"] = $row["is_litItalienne"];
			$room["is_cadeauChocolat"] = $row["is_cadeauChocolat"];
			$room["is_cadeauChampagne"] = $row["is_cadeauChampagne"];
			$room["is_cadeauFleur"] = $row["is_cadeauFleur"];
			array_push($rooms,$room); 
		}
		//echo json_encode($rooms);
		return $rooms;
	} else {
		$error["succes"] = false;
		$error["message"] = "Aucune chambre dans cette etage";
		// echo no users JSON
		//echo json_encode($error);
		return false;
	}
	deconnection_bdd($bdd);
	
}

function  getRooms_IdFloor($id_floor){
	
		$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM datacsv 	WHERE Floor_Label=".$id_floor." ORDER BY id ASC") or die(mysqli_error($bdd));

	// check for empty result
	if (mysqli_num_rows($result) > 0) {
		// looping through all results
		$rooms = array();
		 
		while( $row = mysqli_fetch_array($result) ) {
			
			$room["id"] = $row["id"];
			$room["room_id"] = $row["room_id"];
			$room["room_num"] = $row["room_num"];
			$room["HXXType"] = $row["HXXType"];
			$room["ResidentOrGuest"] = $row["ResidentOrGuest"];
			$room["Etat"] = $row["Etat"];			
			$room["Lign_date"] = $row["Lign_date"];
			$room["PassedNights"] = $row["PassedNights"];
			$room["RemainingNights"] = $row["RemainingNights"];
			$room["StayStatus"] = $row["StayStatus"];
			$room["RoomStatusAfterH12"] = $row["RoomStatusAfterH12"];			
			$room["Floor_Label"] = $row["Floor_Label"];
			$room["Floor_Id"] = $row["Floor_Id"];
			$room["LinkSP"] = $row["LinkSP"];
			$room["Date_created"] = $row["Date_created"];
			$room["is_litBebe"] = $row["is_litBebe"];
			$room["is_porteOuverte"] = $row["is_porteOuverte"];
			$room["is_porteFermee"] = $row["is_porteFermee"];
			$room["is_canapeOuvert"] = $row["is_canapeOuvert"];
			$room["is_canapeFerme"] = $row["is_canapeFerme"];
			$room["is_litItalienne"] = $row["is_litItalienne"];
			$room["is_cadeauChocolat"] = $row["is_cadeauChocolat"];
			$room["is_cadeauChampagne"] = $row["is_cadeauChampagne"];
			$room["is_cadeauFleur"] = $row["is_cadeauFleur"];
			array_push($rooms,$room); 
		}
		//echo json_encode($rooms);
		return $rooms;
	} else {
		$error["succes"] = false;
		$error["message"] = "Aucune chambre dans cette etage";
		// echo no users JSON
		//echo json_encode($error);
		return false;
	}
	deconnection_bdd($bdd);
	
}

function getRoomsOccupiedClean(){
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM datacsv WHERE Etat='OCC-Prp' ORDER BY id ASC") or die(mysqli_error($bdd));

	// check for empty result
	if (mysqli_num_rows($result) > 0) {
		// looping through all results
		$rooms = array();
		 
		while( $row = mysqli_fetch_array($result) ) {
			$room["id"] = $row["id"];
			$room["room_id"] = $row["room_id"];
			$room["room_num"] = $row["room_num"];
			$room["HXXType"] = $row["HXXType"];
			$room["ResidentOrGuest"] = $row["ResidentOrGuest"];
			$room["Etat"] = $row["Etat"];			
			$room["Lign_date"] = $row["Lign_date"];
			$room["PassedNights"] = $row["PassedNights"];
			$room["RemainingNights"] = $row["RemainingNights"];
			$room["StayStatus"] = $row["StayStatus"];
			$room["RoomStatusAfterH12"] = $row["RoomStatusAfterH12"];			
			$room["Floor_Label"] = $row["Floor_Label"];
			$room["Floor_Id"] = $row["Floor_Id"];
			$room["LinkSP"] = $row["LinkSP"];
			$room["Date_created"] = $row["Date_created"];
			$room["is_litBebe"] = $row["is_litBebe"];
			$room["is_porteOuverte"] = $row["is_porteOuverte"];
			$room["is_porteFermee"] = $row["is_porteFermee"];
			$room["is_canapeOuvert"] = $row["is_canapeOuvert"];
			$room["is_canapeFerme"] = $row["is_canapeFerme"];
			$room["is_litItalienne"] = $row["is_litItalienne"];
			$room["is_cadeauChocolat"] = $row["is_cadeauChocolat"];
			$room["is_cadeauChampagne"] = $row["is_cadeauChampagne"];
			$room["is_cadeauFleur"] = $row["is_cadeauFleur"];
			array_push($rooms, $room); 
		}
		echo json_encode($rooms);
	} else {
		$error["succes"] = false;
		$error["message"] = "Aucune chambre propre et occupée";
		// echo no users JSON
		echo json_encode($error);
	}
	deconnection_bdd($bdd);
}

function getRoomsOccupieDirty(){
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM datacsv WHERE Etat='OCC-Sal'ORDER BY id ASC") or die(mysqli_error($bdd));

	// check for empty result
	if (mysqli_num_rows($result) > 0) {
		// looping through all results
		$rooms = array();
		 
		while( $row = mysqli_fetch_array($result) ) {
			//$employe = getEmploye_id($row["EMP_ID"]);
			$room["id"] = $row["id"];
			$room["room_id"] = $row["room_id"];
			$room["room_num"] = $row["room_num"];
			$room["HXXType"] = $row["HXXType"];
			$room["ResidentOrGuest"] = $row["ResidentOrGuest"];
			$room["Etat"] = $row["Etat"];			
			$room["Lign_date"] = $row["Lign_date"];
			$room["PassedNights"] = $row["PassedNights"];
			$room["RemainingNights"] = $row["RemainingNights"];
			$room["StayStatus"] = $row["StayStatus"];
			$room["RoomStatusAfterH12"] = $row["RoomStatusAfterH12"];			
			$room["Floor_Label"] = $row["Floor_Label"];
			$room["Floor_Id"] = $row["Floor_Id"];
			$room["LinkSP"] = $row["LinkSP"];
			$room["Date_created"] = $row["Date_created"];
			$room["is_litBebe"] = $row["is_litBebe"];
			$room["is_porteOuverte"] = $row["is_porteOuverte"];
			$room["is_porteFermee"] = $row["is_porteFermee"];
			$room["is_canapeOuvert"] = $row["is_canapeOuvert"];
			$room["is_canapeFerme"] = $row["is_canapeFerme"];
			$room["is_litItalienne"] = $row["is_litItalienne"];
			$room["is_cadeauChocolat"] = $row["is_cadeauChocolat"];
			$room["is_cadeauChampagne"] = $row["is_cadeauChampagne"];
			$room["is_cadeauFleur"] = $row["is_cadeauFleur"];
			array_push($rooms, $room); 
		}
		echo json_encode($rooms);
	} else {
		$error["succes"] = false;
		$error["message"] = "Aucune chambre sale et occupée";
		// echo no users JSON
		echo json_encode($error);
	}
	deconnection_bdd($bdd);
}

function getRoomsFreeDirty(){
//function getTousEmployes_par_type($type){
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM datacsv WHERE Etat='LIB-Sal'ORDER BY id ASC") or die(mysqli_error($bdd));

	// check for empty result
	if (mysqli_num_rows($result) > 0) {
		// looping through all results
		$rooms = array();
		 
		while( $row = mysqli_fetch_array($result) ) {
			//$employe = getEmploye_id($row["EMP_ID"]);
			$room["id"] = $row["id"];
			$room["room_id"] = $row["room_id"];
			$room["room_num"] = $row["room_num"];
			$room["HXXType"] = $row["HXXType"];
			$room["ResidentOrGuest"] = $row["ResidentOrGuest"];
			$room["Etat"] = $row["Etat"];			
			$room["Lign_date"] = $row["Lign_date"];
			$room["PassedNights"] = $row["PassedNights"];
			$room["RemainingNights"] = $row["RemainingNights"];
			$room["StayStatus"] = $row["StayStatus"];
			$room["RoomStatusAfterH12"] = $row["RoomStatusAfterH12"];			
			$room["Floor_Label"] = $row["Floor_Label"];
			$room["Floor_Id"] = $row["Floor_Id"];
			$room["LinkSP"] = $row["LinkSP"];
			$room["Date_created"] = $row["Date_created"];
			$room["is_litBebe"] = $row["is_litBebe"];
			$room["is_porteOuverte"] = $row["is_porteOuverte"];
			$room["is_porteFermee"] = $row["is_porteFermee"];
			$room["is_canapeOuvert"] = $row["is_canapeOuvert"];
			$room["is_canapeFerme"] = $row["is_canapeFerme"];
			$room["is_litItalienne"] = $row["is_litItalienne"];
			$room["is_cadeauChocolat"] = $row["is_cadeauChocolat"];
			$room["is_cadeauChampagne"] = $row["is_cadeauChampagne"];
			$room["is_cadeauFleur"] = $row["is_cadeauFleur"];
			array_push($rooms, $room); 
		}
		echo json_encode($rooms);
	} else {
		$error["succes"] = false;
		$error["message"] = "Aucune chambre sale et libre";
		// echo no users JSON
		echo json_encode($error);
	}
	deconnection_bdd($bdd);
}

function getRoomsFreeClean(){
//function getTousEmployes_par_type($type){
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM datacsv WHERE Etat='LIB-Prp'ORDER BY id ASC") or die(mysqli_error($bdd));

	// check for empty result
	if (mysqli_num_rows($result) > 0) {
		// looping through all results
		$rooms = array();
		 
		while( $row = mysqli_fetch_array($result) ) {
			//$employe = getEmploye_id($row["EMP_ID"]);
			$room["id"] = $row["id"];
			$room["room_id"] = $row["room_id"];
			$room["room_num"] = $row["room_num"];
			$room["HXXType"] = $row["HXXType"];
			$room["ResidentOrGuest"] = $row["ResidentOrGuest"];
			$room["Etat"] = $row["Etat"];			
			$room["Lign_date"] = $row["Lign_date"];
			$room["PassedNights"] = $row["PassedNights"];
			$room["RemainingNights"] = $row["RemainingNights"];
			$room["StayStatus"] = $row["StayStatus"];
			$room["RoomStatusAfterH12"] = $row["RoomStatusAfterH12"];			
			$room["Floor_Label"] = $row["Floor_Label"];
			$room["Floor_Id"] = $row["Floor_Id"];
			$room["LinkSP"] = $row["LinkSP"];
			$room["Date_created"] = $row["Date_created"];
			$room["is_litBebe"] = $row["is_litBebe"];
			$room["is_porteOuverte"] = $row["is_porteOuverte"];
			$room["is_porteFermee"] = $row["is_porteFermee"];
			$room["is_canapeOuvert"] = $row["is_canapeOuvert"];
			$room["is_canapeFerme"] = $row["is_canapeFerme"];
			$room["is_litItalienne"] = $row["is_litItalienne"];
			$room["is_cadeauChocolat"] = $row["is_cadeauChocolat"];
			$room["is_cadeauChampagne"] = $row["is_cadeauChampagne"];
			$room["is_cadeauFleur"] = $row["is_cadeauFleur"];
			array_push($rooms, $room); 
		}
		echo json_encode($rooms);
	} else {
		$error["succes"] = false;
		$error["message"] = "Aucune chambre propre et libre";
		// echo no users JSON
		echo json_encode($error);
	}
	deconnection_bdd($bdd);
}

function getRoomsHS(){
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM datacsv WHERE Etat='HS-Sal' ORDER BY id ASC") or die(mysqli_error($bdd));

	// check for empty result
	if (mysqli_num_rows($result) > 0) {
		// looping through all results
		$rooms = array();
		 
		while( $row = mysqli_fetch_array($result) ) {
			$room["id"] = $row["id"];
			$room["room_id"] = $row["room_id"];
			$room["room_num"] = $row["room_num"];
			$room["HXXType"] = $row["HXXType"];
			$room["ResidentOrGuest"] = $row["ResidentOrGuest"];
			$room["Etat"] = $row["Etat"];			
			$room["Lign_date"] = $row["Lign_date"];
			$room["PassedNights"] = $row["PassedNights"];
			$room["RemainingNights"] = $row["RemainingNights"];
			$room["StayStatus"] = $row["StayStatus"];
			$room["RoomStatusAfterH12"] = $row["RoomStatusAfterH12"];			
			$room["Floor_Label"] = $row["Floor_Label"];
			$room["Floor_Id"] = $row["Floor_Id"];
			$room["LinkSP"] = $row["LinkSP"];
			$room["Date_created"] = $row["Date_created"];
			$room["is_litBebe"] = $row["is_litBebe"];
			$room["is_porteOuverte"] = $row["is_porteOuverte"];
			$room["is_porteFermee"] = $row["is_porteFermee"];
			$room["is_canapeOuvert"] = $row["is_canapeOuvert"];
			$room["is_canapeFerme"] = $row["is_canapeFerme"];
			$room["is_litItalienne"] = $row["is_litItalienne"];
			$room["is_cadeauChocolat"] = $row["is_cadeauChocolat"];
			$room["is_cadeauChampagne"] = $row["is_cadeauChampagne"];
			$room["is_cadeauFleur"] = $row["is_cadeauFleur"];
			array_push($rooms, $room); 
		}
		echo json_encode($rooms);
	} else {
		$error["succes"] = false;
		$error["message"] = "Aucune chambre HS";
		// echo no users JSON
		echo json_encode($error);
	}
	deconnection_bdd($bdd);
}

function updateRoom_clean($RoomId ,$Etat ){
		$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
		if($Etat == 'LIB-Sal') { $Etat = "LIB-Prp";}
		if($Etat == 'OCC-Sal') { $Etat = "OCC-Prp";}
		if($Etat == 'HS-Sal')  { $Etat = "LIB-Prp";}
	$result = $bdd->query("UPDATE datacsv
						  SET Etat='".$Etat."'						   
						  WHERE id='".$RoomId."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	
	if ( $bdd->affected_rows > 0 ) {		
		
		return true;
	}else{	
		return false;
	}
	deconnection_bdd($bdd);
}

function updateRoom_dirty($RoomId ,$Etat ){
		$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
		if($Etat == 'LIB-Prp') { $Etat = "LIB-Sal";}
		if($Etat == 'OCC-Prp') { $Etat = "OCC-Sal";}
		if($Etat == 'HS-Sal')  { $Etat = "LIB-Sal";}
	$result = $bdd->query("UPDATE datacsv
						  SET Etat='".$Etat."'						   
						  WHERE id='".$RoomId."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	
	if ( $bdd->affected_rows > 0 ) {		
		
		return true;
	}else{
		return false;
	}
	deconnection_bdd($bdd);
}

function  updateRoom_HS($RoomId ,$Etat ){
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
		if($Etat == 'LIB-Prp') { $Etat = "HS-Sal";}
		if($Etat == 'OCC-Prp') { $Etat = "HS-Sal";}
		if($Etat == 'LIB-Sal') { $Etat = "HS-Sal";}
		if($Etat == 'OCC-Sal') { $Etat = "HS-Sal";}
		if($Etat == 'HS-Sal')  { $Etat = "HS-Sal";}
	$result = $bdd->query("UPDATE datacsv
						  SET Etat='".$Etat."'						   
						  WHERE id='".$RoomId."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	
	if ( $bdd->affected_rows > 0 ) {		
		
		return true;
	}else{
		return false;
	}
	deconnection_bdd($bdd);
}	

function  updateRoom_FM_ID($id_FM ,$value){
		$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$date =(new \DateTime())->format('Y-m-d');	
	$result = $bdd->query("UPDATE chambresaffectees
						  SET id_FM='".$id_FM."'						   
						  WHERE room_num='".$value."' AND date_created='".$date."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	
	if ( $bdd->affected_rows > 0 ) {		
		
		return true;
	}else{	
		return false;
	}
	deconnection_bdd($bdd);	
	
}

function PlanningExiste(){
	$date =(new \DateTime())->format('Y-m-d');
	
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	$result = $bdd->query("SELECT * FROM chambresaffectees WHERE date_created=".$date."  ORDER BY id ASC") or die(mysqli_error($bdd));
	var_dump($result);
	if (mysqli_num_rows($result) > 0) {
		deconnection_bdd($bdd);
		return true;
	}
	
	deconnection_bdd($bdd);
	return false;
}

function PlanningExiste2(){
	$date =(new \DateTime())->format('Y-m-d');
	
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
	
	//$str = "SELECT DISTINCT  id_FM FROM chambresaffectees WHERE date_created = '".$date."' ORDER BY id ASC";
	//var_dump($str);
	$result = $bdd->query("SELECT DISTINCT id_FM  FROM chambresaffectees WHERE date_created = '".$date."' ORDER BY id ASC") or die(mysqli_error($bdd));
	//var_dump($result);
		
	if (mysqli_num_rows($result) > 0) {
		$FDC = array();
		 
		while( $row = mysqli_fetch_array($result) ) {
			//$employe = getEmploye_id($row["EMP_ID"]);
			//var_dump($row);
			$id = $row["id_FM"];
			
			$femme = getFemmesDeMenage_ID($id);
			array_push($FDC, $femme); 
		}
		//var_dump($FDC);
		echo json_encode($FDC);
		return $FDC;
	} else {
		$error["succes"] = false;
		$error["message"] = "Pas de planning pour aujourd'hui !!!";
		
		echo json_encode($error);
		return null;
	}
	deconnection_bdd($bdd);
	
	
}				

function desactiver_FM($id){
		$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
		
	$result = $bdd->query("UPDATE femmedemenage
						  SET is_active='0'						   
						  WHERE id='".$id."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	
	if ( $bdd->affected_rows > 0 ) {		
		
		return true;
	}else{	
		return false;
	}
	deconnection_bdd($bdd);
}

function activer_FM($id){
		$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);
		
	$result = $bdd->query("UPDATE femmedemenage
						  SET is_active='1'						   
						  WHERE id='".$id."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	
	if ( $bdd->affected_rows > 0 ) {		
		
		return true;
	}else{	
		return false;
	}
	deconnection_bdd($bdd);
}

function  update_FM($id_FM,$nom,$prenom,$presence,$etage,$secteur,$code,$is_active){
	//var_dump($id_FM);
	
	$bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);		
	$result = $bdd->query("UPDATE femmedemenage
						  SET nom='".$nom."',
						      prenom='".$prenom."',
							  presence='".$presence."',
							  secteur='".$secteur."',
						      code='".$code."',
							  is_active='".$is_active."'                               						  
						  WHERE id='".$id_FM."' ORDER BY id  ASC") or die(mysqli_error($bdd));
	
	if ( $bdd->affected_rows > 0 ) {		
		//echo json_encode(true);
		return true;
	}else{	
	//echo json_encode(false);
		return false;
	}
	deconnection_bdd($bdd);
}

function add_FM($nom,$prenom,$presence,$etage,$secteur,$code,$is_active){
	   $bdd = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);		

	$result = $bdd->query("INSERT INTO femmedemenage (nom,prenom,presence,secteur,code,is_active)
	 VALUES(
	 '".$nom."',
	 '".$prenom."',
	 '".$presence."',
	 '".$secteur."',	
	 '".$etage."',
     '".$code."',	 
	 '".$is_active."')") or die(mysqli_error($bdd));
	 
	if ( $bdd->affected_rows > 0 ) {		
		//echo json_encode(true);
		return true;
	}else{	
	//echo json_encode(false);
		return false;
	}
	deconnection_bdd($bdd);	
}
?>