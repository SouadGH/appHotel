<?php
header("Access-Control-Allow-Origin:*");
require('fonctions_femmesDeMenage.php');

//http://stackoverflow.com/questions/18382740/cors-not-working-php
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }
 
    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
 
        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         
 
        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
 
        exit(0);
    }
 
 
 
//$postdata = file_get_contents("php://input"); var_dump($postdata);
/*$postdata = '[  
   {  
      "id_FM":"1",
      "nom":"FATIME",
      "prenom":"prenom 1",
      "presence":true,
      "etage":"2"
   },
   {  
      "id_FM":"3",
      "nom":"CHARLENE",
      "prenom":"prenom 3",
      "presence":true,
      "etage":"3"
   },
   {  
      "id_FM":"5",
      "nom":"HAWAOU",
      "prenom":"prenom 5",
      "presence":true,
      "etage":"4"
   }
]';*/
/*$json = json_decode($postdata, true); var_dump($json);

 foreach($postdata as $value){
  echo 'etage est : ' .$json['id_FM'] ;
  $id = $json['id_FM'];
  $etage = $json['etage'];
  addRoomsAffected($id,$etage);


 }*/

 
 
 $postdata = file_get_contents("php://input");
 //var_dump($postdata);
// if (isset($postdata)) {
$request = json_decode($postdata);
foreach($request as $value){
  $id = $value->id_FM;
  $etage = $value->etage;
  $secteur = $value->secteur;
  addRoomsAffected($id,$etage,$secteur);
}

//}
 
 


 
   
  //print_r($postdata);
  //if (isset($postdata)) {
       // $request = json_decode($postdata['femmes']);
		//var_dump($request);
		//$femmes = array();
		//$femmes = $request->femmes;
		//var_dump($femmes);
		 //$json_data = json_decode($postdata);
		// foreach($json_data as $value){
			//foreach( $request as $value)
			
				//$id_FM = $json_data->id_FM;
		       // $etage = $json_data->etage;
				//addRoomsAffected($id_FM,$etage);	
		//	}
			
//}
?>