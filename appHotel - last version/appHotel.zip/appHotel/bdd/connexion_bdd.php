<?php
header("Access-Control-Allow-Origin:*");
/*
"212.147.66.230", "dandela_admin"
*/
define('SERVEUR', "127.0.0.1");
define('UTILISATEUR', "root");
define('MOT_DE_PASSE', "");
define('NOM_BDD', "menage");
define('FORMAT_DATE', "jj/mm/aaaa hh:mm");

$BDD_GLOBALE = connection_bdd(SERVEUR, UTILISATEUR, MOT_DE_PASSE, NOM_BDD);


function connection_bdd($localhost, $user, $password, $bdd){
	$connexion = new mysqli($localhost, $user, $password, $bdd) or die(mysql_error());// connexion à la base , ici : "" = mon mot de passe
	$connexion->query("SET NAMES UTF8");
	return $connexion;
}

function deconnection_bdd($connexion){
	mysqli_close($connexion);
}
?>